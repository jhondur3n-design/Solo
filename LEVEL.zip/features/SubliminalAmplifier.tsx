import React, { useState } from 'react';
import { UIAudioTrack, ProcessingProgress } from '../types';
import { BrainCircuit, Download } from '../components/Icons';
import { bufferToWave } from '../utils/audio';

const audioContext = new (window.AudioContext || (window as any).webkitAudioContext)();

const SubliminalAmplifier: React.FC = () => {
    const [sourceTrack, setSourceTrack] = useState<UIAudioTrack | null>(null);
    const [progress, setProgress] = useState<ProcessingProgress>({ status: 'idle', message: 'Load a subliminal track to begin.' });

    // EQ settings
    const [lowGain, setLowGain] = useState(0); // in dB
    const [midGain, setMidGain] = useState(0); // in dB
    const [highGain, setHighGain] = useState(0); // in dB
    const [harmonics, setHarmonics] = useState(0); // 0 to 100

    const handleFileChange = async (event: React.ChangeEvent<HTMLInputElement>) => {
        const file = event.target.files?.[0];
        if (!file || !audioContext) return;

        try {
            setProgress({ status: 'processing', message: 'Decoding audio...' });
            const arrayBuffer = await file.arrayBuffer();
            const audioBuffer = await audioContext.decodeAudioData(arrayBuffer);
            setSourceTrack({
                id: `${Date.now()}-${file.name}`,
                name: file.name,
                buffer: audioBuffer,
            });
            setProgress({ status: 'idle', message: `${file.name} loaded successfully.` });
        } catch (error) {
            console.error('Error decoding audio file:', error);
            setProgress({ status: 'error', message: 'Error decoding audio file.' });
        }
    };

    const makeDistortionCurve = (amount: number) => {
        const k = typeof amount === 'number' ? amount : 50;
        const n_samples = 44100;
        const curve = new Float32Array(n_samples);
        const deg = Math.PI / 180;
        let i = 0;
        let x;
        for ( ; i < n_samples; ++i ) {
            x = i * 2 / n_samples - 1;
            curve[i] = ( 3 + k ) * x * 20 * deg / ( Math.PI + k * Math.abs(x) );
        }
        return curve;
    };

    const handleExport = async () => {
        if (!sourceTrack) {
            setProgress({ status: 'error', message: 'No source track loaded.' });
            return;
        }
        setProgress({ status: 'processing', message: 'Applying enhancements...' });

        const offlineCtx = new OfflineAudioContext(sourceTrack.buffer.numberOfChannels, sourceTrack.buffer.length, sourceTrack.buffer.sampleRate);

        const source = offlineCtx.createBufferSource();
        source.buffer = sourceTrack.buffer;

        // EQ Filters
        const lowShelf = offlineCtx.createBiquadFilter();
        lowShelf.type = 'lowshelf';
        lowShelf.frequency.value = 320;
        lowShelf.gain.value = lowGain;

        const midPeaking = offlineCtx.createBiquadFilter();
        midPeaking.type = 'peaking';
        midPeaking.frequency.value = 1000;
        midPeaking.Q.value = Math.SQRT1_2;
        midPeaking.gain.value = midGain;

        const highShelf = offlineCtx.createBiquadFilter();
        highShelf.type = 'highshelf';
        highShelf.frequency.value = 3200;
        highShelf.gain.value = highGain;

        // Harmonic Enrichment (Distortion)
        const distortion = offlineCtx.createWaveShaper();
        distortion.curve = makeDistortionCurve(harmonics * 2); // scale harmonics for more effect
        distortion.oversample = '4x';

        // Connect nodes
        source.connect(lowShelf);
        lowShelf.connect(midPeaking);
        midPeaking.connect(highShelf);

        if (harmonics > 0) {
            highShelf.connect(distortion);
            distortion.connect(offlineCtx.destination);
        } else {
            highShelf.connect(offlineCtx.destination);
        }
        
        source.start();

        try {
            setProgress({ status: 'processing', message: 'Rendering amplified audio...' });
            const renderedBuffer = await offlineCtx.startRendering();
            const wavBlob = bufferToWave(renderedBuffer);
            
            const url = URL.createObjectURL(wavBlob);
            const a = document.createElement('a');
            a.href = url;
            a.download = `amplified-${sourceTrack.name}`;
            document.body.appendChild(a);
            a.click();
            URL.revokeObjectURL(url);
            a.remove();
            setProgress({ status: 'done', message: 'Amplification complete. System ready.' });
        } catch (error) {
            console.error('Error rendering audio:', error);
            setProgress({ status: 'error', message: 'An error occurred during export.' });
        }
    };
    
    const ParameterSlider: React.FC<{label: string, value: number, onChange: (v: number) => void, min?: number, max?: number, unit?: string}> = 
    ({ label, value, onChange, min = -24, max = 24, unit="dB" }) => (
        <div>
            <label className="block text-sm font-medium text-brand-text-dark tracking-wider">{label}: {value.toFixed(1)}{unit}</label>
            <input type="range" min={min} max={max} step="0.1" value={value} onChange={e => onChange(Number(e.target.value))} className="w-full h-2 mt-1 bg-brand-primary/30 rounded-lg appearance-none cursor-pointer accent-brand-primary" />
        </div>
    );

    return (
        <div className="animate-fade-in">
            <h2 className="text-2xl font-bold text-brand-primary mb-1 tracking-widest">[MODULE] AMPLIFIER</h2>
            <p className="mb-6 text-brand-text-dark border-b-2 border-brand-primary/20 pb-2">Enhance and intensify subliminal audio tracks. All processing is local.</p>

            <div className="space-y-6">
                <div className="bg-brand-bg/50 p-4 border border-brand-primary/20">
                    <h3 className="font-semibold text-lg text-brand-primary tracking-wider mb-3">[System] Load Audio</h3>
                    <input type="file" accept="audio/*" onChange={handleFileChange} className="w-full text-sm text-brand-text-dark file:mr-4 file:py-2 file:px-4 file:rounded-none file:border-2 file:border-brand-accent/50 file:text-sm file:font-semibold file:bg-transparent file:text-brand-accent hover:file:bg-brand-accent hover:file:text-brand-bg transition-colors duration-300 cursor-pointer"/>
                    {sourceTrack && <p className="text-sm text-brand-text mt-3 bg-brand-surface p-2">Loaded: <span className="font-semibold">{sourceTrack.name}</span></p>}
                </div>

                {sourceTrack && (
                    <>
                        <div className="bg-brand-bg/50 p-4 border border-brand-primary/20">
                            <h3 className="font-semibold text-lg text-brand-primary tracking-wider mb-4">[Matrix] Dynamic Frequency Sculpting</h3>
                            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                               <ParameterSlider label="Low Frequencies (Bass)" value={lowGain} onChange={setLowGain} />
                               <ParameterSlider label="Mid Frequencies (Mids)" value={midGain} onChange={setMidGain} />
                               <ParameterSlider label="High Frequencies (Treble)" value={highGain} onChange={setHighGain} />
                            </div>
                        </div>

                         <div className="bg-brand-bg/50 p-4 border border-brand-primary/20">
                            <h3 className="font-semibold text-lg text-brand-primary tracking-wider mb-4">[Matrix] Harmonic Enrichment</h3>
                             <ParameterSlider label="Enrichment Level" value={harmonics} onChange={setHarmonics} min={0} max={100} unit="%" />
                        </div>
                        
                        <div className="bg-brand-surface p-4 border-2 border-brand-accent/80">
                            <div className="flex flex-col md:flex-row items-center justify-between gap-4">
                                <p className={`font-semibold tracking-wider ${progress.status === 'error' ? 'text-red-500' : 'text-brand-accent'}`}>
                                    {progress.status === 'processing' && <span className="animate-pulse">SYSTEM BUSY: </span>}
                                    {progress.message}
                                </p>
                                <button onClick={handleExport} disabled={progress.status === 'processing'} className="w-full md:w-auto bg-brand-accent text-brand-bg font-bold py-3 px-8 transition-all duration-300 tracking-widest text-lg hover:shadow-glow hover:shadow-brand-accent/50 disabled:bg-gray-500 disabled:cursor-not-allowed disabled:shadow-none">
                                  {progress.status === 'processing' ? 'PROCESSING...' : 'EXPORT AMPLIFIED'}
                                </button>
                            </div>
                        </div>
                    </>
                )}

                {!sourceTrack && (
                     <div className="flex flex-col items-center justify-center text-center p-8 animate-pulse-glow">
                        <div className="w-24 h-24 text-brand-primary/50 mb-6">
                            <BrainCircuit />
                        </div>
                        <p className="text-brand-text-dark">Awaiting audio file input...</p>
                    </div>
                )}
            </div>
        </div>
    );
};

export default SubliminalAmplifier;
