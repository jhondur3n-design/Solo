import React, { useState, useRef, useEffect } from 'react';
import { Radio } from '../components/Icons';

const RadionicsModule: React.FC = () => {
    const [targetImage, setTargetImage] = useState<string | null>(null);
    const [powerLevel, setPowerLevel] = useState(50);
    const [isBroadcasting, setIsBroadcasting] = useState(false);
    
    const audioContextRef = useRef<AudioContext | null>(null);
    const oscillatorRef = useRef<OscillatorNode | null>(null);
    const gainRef = useRef<GainNode | null>(null);

    useEffect(() => {
        return () => { // Cleanup on unmount
            if(isBroadcasting) {
                handleBroadcastToggle();
            }
        }
    }, [isBroadcasting]);

    const handleImageUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
        const file = event.target.files?.[0];
        if (file) {
            const reader = new FileReader();
            reader.onload = (e) => setTargetImage(e.target?.result as string);
            reader.readAsDataURL(file);
        }
    };

    const handleBroadcastToggle = () => {
        if (!isBroadcasting) {
            // Start Broadcasting
            audioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)();
            oscillatorRef.current = audioContextRef.current.createOscillator();
            gainRef.current = audioContextRef.current.createGain();

            oscillatorRef.current.type = 'sine';
            oscillatorRef.current.frequency.setValueAtTime(40 + (powerLevel / 10), audioContextRef.current.currentTime);
            gainRef.current.gain.setValueAtTime(0, audioContextRef.current.currentTime);
            gainRef.current.gain.exponentialRampToValueAtTime(0.1, audioContextRef.current.currentTime + 1);

            oscillatorRef.current.connect(gainRef.current);
            gainRef.current.connect(audioContextRef.current.destination);
            oscillatorRef.current.start();
            setIsBroadcasting(true);
        } else {
            // Stop Broadcasting
            if (audioContextRef.current && gainRef.current) {
                gainRef.current.gain.exponentialRampToValueAtTime(0.0001, audioContextRef.current.currentTime + 1);
                oscillatorRef.current?.stop(audioContextRef.current.currentTime + 1);
                setTimeout(() => {
                    audioContextRef.current?.close();
                }, 1500);
            }
            setIsBroadcasting(false);
        }
    };

    useEffect(() => {
        if(isBroadcasting && oscillatorRef.current && audioContextRef.current){
             oscillatorRef.current.frequency.setValueAtTime(40 + (powerLevel / 10), audioContextRef.current.currentTime);
        }
    }, [powerLevel, isBroadcasting]);

    const broadcastButtonClass = isBroadcasting ? 
        'bg-red-500 border-red-500 text-white hover:bg-red-600 animate-pulse' : 
        'bg-brand-accent border-brand-accent text-brand-bg hover:shadow-glow hover:shadow-brand-accent/50';

    return (
        <div className="animate-fade-in">
            <h2 className="text-2xl font-bold text-brand-primary mb-1 tracking-widest">[MODULE] RADIONICS</h2>
            <p className="mb-6 text-brand-text-dark border-b-2 border-brand-primary/20 pb-2">Focus and broadcast intention through energetic fields.</p>
            
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                {/* Controls */}
                <div className="space-y-6">
                    <div className="bg-brand-bg/50 p-4 border border-brand-primary/20">
                        <h3 className="font-semibold text-lg text-brand-primary tracking-wider mb-3">[Log] Intention Field</h3>
                        <textarea className="w-full h-28 p-2 bg-brand-surface border-2 border-brand-primary/30 rounded-none focus:border-brand-primary focus:ring-0 placeholder:text-brand-text-dark/50" placeholder="Input your intention, wish, or goal..."></textarea>
                    </div>

                    <div className="bg-brand-bg/50 p-4 border border-brand-primary/20">
                        <h3 className="font-semibold text-lg text-brand-primary tracking-wider mb-3">[System] Target Sigil</h3>
                        <input type="file" accept="image/*" onChange={handleImageUpload} className="w-full text-sm text-brand-text-dark file:mr-4 file:py-2 file:px-4 file:rounded-none file:border-2 file:border-brand-accent/50 file:text-sm file:font-semibold file:bg-transparent file:text-brand-accent hover:file:bg-brand-accent hover:file:text-brand-bg transition-colors duration-300 cursor-pointer"/>
                    </div>

                    <div className="bg-brand-bg/50 p-4 border border-brand-primary/20">
                        <h3 className="font-semibold text-lg text-brand-primary tracking-wider mb-3">[System] Power Level: {powerLevel}%</h3>
                        <input type="range" min="0" max="100" value={powerLevel} onChange={e => setPowerLevel(Number(e.target.value))} className="w-full h-2 bg-brand-primary/30 rounded-lg appearance-none cursor-pointer accent-brand-primary" />
                    </div>
                </div>

                {/* Broadcast Dish */}
                <div className="bg-brand-bg/50 p-4 border border-brand-primary/20 flex items-center justify-center min-h-[300px] lg:min-h-full">
                    <div className="relative w-64 h-64 flex items-center justify-center">
                        {isBroadcasting && Array.from({ length: 4 }).map((_, i) => (
                           <div key={i} 
                                className="absolute rounded-full border-2 border-brand-primary/50"
                                style={{
                                    width: `${(i+1)*25}%`,
                                    height: `${(i+1)*25}%`,
                                    animation: `pulse-glow ${2 + i*0.5}s infinite ease-in-out`,
                                    animationDelay: `${i*0.2}s`
                                }}></div>
                        ))}
                        <div className="relative w-48 h-48 bg-brand-surface rounded-full flex items-center justify-center border-2 border-brand-primary/30 overflow-hidden">
                            {targetImage ? (
                                <img src={targetImage} alt="Target Sigil" className="w-full h-full object-cover" />
                            ) : (
                                <Radio className={`w-24 h-24 transition-colors duration-500 ${isBroadcasting ? 'text-brand-primary' : 'text-brand-primary/30'}`} />
                            )}
                        </div>
                    </div>
                </div>

                {/* Action Panel */}
                <div className="lg:col-span-2 bg-brand-surface p-4 border-2 border-brand-accent/80">
                     <button onClick={handleBroadcastToggle} className={`w-full font-bold py-3 px-8 transition-all duration-300 tracking-widest text-lg border-2 ${broadcastButtonClass}`}>
                        {isBroadcasting ? 'CEASE BROADCAST' : 'INITIATE BROADCAST'}
                     </button>
                </div>
            </div>
        </div>
    );
};

export default RadionicsModule;
