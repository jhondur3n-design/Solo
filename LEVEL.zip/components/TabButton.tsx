import React from 'react';

interface TabButtonProps {
  label: string;
  // Fix: Use React.ReactElement to resolve JSX namespace error.
  icon: React.ReactElement;
  isActive: boolean;
  onClick: () => void;
}

const TabButton: React.FC<TabButtonProps> = ({ label, icon, isActive, onClick }) => {
  const baseClasses = 'flex items-center justify-start w-full text-left p-3 my-1 transition-all duration-300 ease-in-out relative group';
  const activeClasses = 'text-brand-primary';
  const inactiveClasses = 'text-brand-text-dark hover:text-brand-primary hover:bg-brand-primary/10';

  return (
    <button onClick={onClick} className={`${baseClasses} ${isActive ? activeClasses : inactiveClasses}`}>
      {isActive && <div className="absolute left-0 top-0 h-full w-1 bg-brand-primary shadow-glow animate-fade-in"></div>}
      <div className={`absolute left-0 top-0 h-full w-full bg-brand-primary/10 opacity-0 group-hover:opacity-100 transition-opacity duration-300 ${isActive ? 'opacity-100' : ''}`}></div>
      <span className="w-6 h-6 mr-4 z-10">{icon}</span>
      <span className="font-semibold tracking-wider z-10 hidden md:inline">{label}</span>
    </button>
  );
};

export default TabButton;
