import React, { useState, useCallback, useEffect } from 'react';
import { Feature, ActiveTab } from './types';
import TabButton from './components/TabButton';
import SubliminalMaker from './features/SubliminalMaker';
import SubliminalAmplifier from './features/SubliminalAmplifier';
import RadionicsModule from './features/RadionicsModule';
import FrequencyGenerator from './features/FrequencyGenerator';
import { BrainCircuit, Dna, Disc, Radio, Download } from './components/Icons';

const App: React.FC = () => {
  const [activeTab, setActiveTab] = useState<ActiveTab>('subliminalMaker');
  const [installPrompt, setInstallPrompt] = useState<any>(null);

  useEffect(() => {
    const handler = (e: Event) => {
        e.preventDefault();
        setInstallPrompt(e);
    };
    window.addEventListener('beforeinstallprompt', handler);
    return () => window.removeEventListener('beforeinstallprompt', handler);
  }, []);

  const handleInstallClick = () => {
    if (!installPrompt) return;
    installPrompt.prompt();
    installPrompt.userChoice.then((choiceResult: { outcome: string }) => {
        if (choiceResult.outcome === 'accepted') {
            console.log('User accepted the install prompt');
        } else {
            console.log('User dismissed the install prompt');
        }
        setInstallPrompt(null);
    });
  };

  const renderContent = useCallback(() => {
    switch (activeTab) {
      case 'subliminalMaker':
        return <SubliminalMaker />;
      case 'subliminalAmplifier':
        return <SubliminalAmplifier />;
      case 'radionicsModule':
        return <RadionicsModule />;
      case 'frequencyGenerator':
        return <FrequencyGenerator />;
      default:
        return null;
    }
  }, [activeTab]);

  const features: Feature[] = [
    { id: 'subliminalMaker', label: 'Subliminal Creation', icon: <Dna /> },
    { id: 'subliminalAmplifier', label: 'Amplifier', icon: <BrainCircuit /> },
    { id: 'radionicsModule', label: 'Radionics', icon: <Radio /> },
    { id: 'frequencyGenerator', label: 'Frequencies', icon: <Disc /> },
  ];

  return (
    <div className="min-h-screen bg-transparent flex flex-col font-sans p-2 sm:p-4">
      <header className="text-center p-4 bg-brand-surface/80 backdrop-blur-sm border-t border-b border-brand-primary/50 relative">
        <div className="absolute top-0 left-0 w-6 h-6 border-t-2 border-l-2 border-brand-primary"></div>
        <div className="absolute top-0 right-0 w-6 h-6 border-t-2 border-r-2 border-brand-primary"></div>
        <div className="absolute bottom-0 left-0 w-6 h-6 border-b-2 border-l-2 border-brand-primary"></div>
        <div className="absolute bottom-0 right-0 w-6 h-6 border-b-2 border-r-2 border-brand-primary"></div>
        <h1 className="text-3xl sm:text-4xl font-bold text-brand-primary tracking-widest uppercase">
          System Interface
        </h1>
        
        {/* Visual Level Indicator */}
        <div className="mt-3 inline-flex items-center justify-center bg-brand-bg/50 px-6 py-1 border border-brand-accent/60 shadow-lg shadow-brand-accent/20">
            <span 
              className="text-brand-accent font-bold tracking-[0.2em] text-lg"
              style={{ textShadow: '0 0 6px rgba(253, 216, 53, 0.7)' }} // fdd835 is brand-accent
            >
              LVL. MAX
            </span>
        </div>
      </header>

      <main className="flex-grow flex flex-col md:flex-row gap-4 mt-4">
        <nav className="flex flex-row md:flex-col bg-brand-surface/80 backdrop-blur-sm p-2 border-y md:border-x border-brand-primary/30 md:w-60">
          <div>
            <div className="w-full p-2 mb-2 border-b-2 border-brand-primary/30">
              <h2 className="text-brand-primary font-bold tracking-wider text-center">[MENU]</h2>
            </div>
            {features.map(feature => (
              <TabButton
                key={feature.id}
                label={feature.label}
                icon={feature.icon}
                isActive={activeTab === feature.id}
                onClick={() => setActiveTab(feature.id)}
              />
            ))}
          </div>
          {installPrompt && (
            <div className="md:mt-auto md:pt-2 md:border-t-2 border-brand-primary/30">
                <button 
                  onClick={handleInstallClick} 
                  className="flex items-center justify-start w-full text-left p-3 my-1 transition-all duration-300 ease-in-out relative group text-brand-accent hover:bg-brand-accent/10"
                >
                    <div className="absolute left-0 top-0 h-full w-full bg-brand-accent/10 opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                    <span className="w-6 h-6 mr-4 z-10"><Download /></span>
                    <span className="font-semibold tracking-wider z-10 hidden md:inline">INSTALL APP</span>
                </button>
            </div>
          )}
        </nav>
        
        <div className="flex-grow bg-brand-surface/80 backdrop-blur-sm p-4 sm:p-6 border border-brand-primary/30 overflow-y-auto relative">
           <div className="absolute -top-px -left-px w-4 h-4 border-t-2 border-l-2 border-brand-primary"></div>
           <div className="absolute -top-px -right-px w-4 h-4 border-t-2 border-r-2 border-brand-primary"></div>
           <div className="absolute -bottom-px -left-px w-4 h-4 border-b-2 border-l-2 border-brand-primary"></div>
           <div className="absolute -bottom-px -right-px w-4 h-4 border-b-2 border-r-2 border-brand-primary"></div>
          {renderContent()}
        </div>
      </main>

      <footer className="text-center p-3 mt-4 text-xs text-brand-text-dark">
        <p>SYSTEM KERNEL V1.0 // CREATOR: <span className="font-semibold text-brand-primary/80">jhondurd3n</span>.</p>
        <p className="mt-1">WARNING: FOR PERSONAL USE ONLY. UNAUTHORIZED ACCESS IS PROHIBITED.</p>
      </footer>
    </div>
  );
};

export default App;