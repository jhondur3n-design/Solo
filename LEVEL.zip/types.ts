import type { ReactElement } from 'react';

export type ActiveTab = 'subliminalMaker' | 'subliminalAmplifier' | 'radionicsModule' | 'frequencyGenerator';

export interface Feature {
  id: ActiveTab;
  label: string;
  // Fix: Use ReactElement to resolve JSX namespace error.
  icon: ReactElement;
}

export interface UIAudioTrack {
  id: string;
  name: string;
  buffer: AudioBuffer;
}

export interface ProcessingProgress {
    status: 'idle' | 'processing' | 'done' | 'error';
    message: string;
}
