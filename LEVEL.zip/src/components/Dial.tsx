import React, { useState, useRef, useCallback, useEffect } from 'react';

interface DialProps {
  label: string;
  value: number;
  onChange: (value: number) => void;
  min?: number;
  max?: number;
  disabled?: boolean;
}

const Dial: React.FC<DialProps> = ({ label, value, onChange, min = 0, max = 100, disabled = false }) => {
  const dialRef = useRef<HTMLDivElement>(null);
  const [isDragging, setIsDragging] = useState(false);

  const valueToAngle = (val: number) => {
    const range = max - min;
    const percentage = (val - min) / range;
    // Map percentage to a -135 to 135 degree range (total 270 degrees of travel)
    return percentage * 270 - 135;
  };

  const angleToValue = useCallback((angle: number) => {
    // Normalize angle to 0-270 range
    const normalizedAngle = angle + 135;
    const percentage = Math.max(0, Math.min(1, normalizedAngle / 270));
    const range = max - min;
    const intValue = Math.round(percentage * range + min);
    return Math.max(min, Math.min(max, intValue));
  }, [min, max]);
  
  const handleInteraction = useCallback((clientX: number, clientY: number) => {
      if (disabled || !dialRef.current) return;
      
      const rect = dialRef.current.getBoundingClientRect();
      const centerX = rect.left + rect.width / 2;
      const centerY = rect.top + rect.height / 2;
      
      const deltaX = clientX - centerX;
      const deltaY = clientY - centerY;
      
      let angle = Math.atan2(deltaY, deltaX) * (180 / Math.PI);

      // Remap angle so 0 is at the top (-90 degrees in atan2)
      angle += 90;
      if (angle < 0) angle += 360;
      
      if (angle > 135 && angle < 225) { // Dead zone at the bottom
        return;
      }

      let finalAngle;
      if (angle >= 225) { // Map 225-360 to -135-0
        finalAngle = angle - 360;
      } else { // 0-135 is fine
        finalAngle = angle;
      }
      
      onChange(angleToValue(finalAngle));
      
  }, [onChange, angleToValue, disabled]);

  const handleMouseDown = (e: React.MouseEvent) => {
    if (disabled) return;
    e.preventDefault();
    setIsDragging(true);
    handleInteraction(e.clientX, e.clientY);
  };
  
  const handleTouchStart = (e: React.TouchEvent) => {
    if (disabled) return;
    setIsDragging(true);
    handleInteraction(e.touches[0].clientX, e.touches[0].clientY);
  };

  useEffect(() => {
    const handleMove = (e: MouseEvent | TouchEvent) => {
      if (!isDragging) return;
      
      // Prevent scrolling on touch devices while dragging
      e.preventDefault();

      const clientX = 'touches' in e ? e.touches[0].clientX : e.clientX;
      const clientY = 'touches' in e ? e.touches[0].clientY : e.clientY;
      handleInteraction(clientX, clientY);
    };

    const handleUp = () => {
      setIsDragging(false);
    };

    if (isDragging) {
      document.addEventListener('mousemove', handleMove);
      document.addEventListener('mouseup', handleUp);
      document.addEventListener('touchmove', handleMove, { passive: false });
      document.addEventListener('touchend', handleUp);
      document.addEventListener('touchcancel', handleUp);
    }
    
    return () => {
      document.removeEventListener('mousemove', handleMove);
      document.removeEventListener('mouseup', handleUp);
      document.removeEventListener('touchmove', handleMove);
      document.removeEventListener('touchend', handleUp);
      document.removeEventListener('touchcancel', handleUp);
    };
  }, [isDragging, handleInteraction]);
  
  const angle = valueToAngle(value);

  return (
    <div className="flex flex-col items-center space-y-1">
      <div 
        ref={dialRef}
        className={`relative w-24 h-24 rounded-full bg-brand-surface border-2 flex items-center justify-center select-none touch-none ${disabled ? 'border-brand-text-dark/20 cursor-not-allowed' : 'border-brand-primary/30 cursor-pointer'}`}
        onMouseDown={handleMouseDown}
        onTouchStart={handleTouchStart}
      >
        <div 
          className="absolute w-full h-full"
          style={{ transform: `rotate(${angle}deg)` }}
        >
          {/* Pointer */}
          <div className={`absolute top-1 left-1/2 -ml-1 w-2 h-4 rounded-full ${disabled ? 'bg-brand-text-dark/50' : 'bg-brand-primary'}`}></div>
        </div>
        {/* Center hub */}
        <div className={`w-4 h-4 rounded-full bg-brand-bg border ${disabled ? 'border-brand-text-dark/20' : 'border-brand-primary/30'}`}></div>
      </div>
      <span className={`text-sm font-semibold tracking-wider ${disabled ? 'text-brand-text-dark/50' : 'text-brand-primary'}`}>
        {label}
      </span>
    </div>
  );
};

export default Dial;
