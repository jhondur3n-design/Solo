import React from 'react';

interface TabButtonProps {
  label: string;
  icon: React.ReactElement;
  isActive: boolean;
  onClick: () => void;
  accent?: boolean;
}

const TabButton: React.FC<TabButtonProps> = ({ label, icon, isActive, onClick, accent }) => {
  const baseClasses = 'flex items-center justify-center py-2 px-3 transition-[color,background-color] duration-300 ease-in-out relative group flex-grow sm:flex-grow-0 rounded-sm';
  
  const activeClasses = 'text-brand-primary';
  const inactiveClasses = accent 
    ? 'text-brand-accent hover:bg-brand-accent/10'
    : 'text-brand-text-dark hover:text-brand-primary hover:bg-brand-primary/10';

  return (
    <button onClick={onClick} className={`${baseClasses} ${isActive ? activeClasses : inactiveClasses}`}>
      {isActive && <div className="absolute left-0 bottom-0 h-1 w-full bg-brand-primary shadow-glow animate-fade-in"></div>}
      <div className={`absolute left-0 top-0 h-full w-full bg-brand-primary/10 opacity-0 group-hover:opacity-100 transition-opacity duration-300 ${isActive ? 'opacity-100' : ''}`}></div>
      <span className="w-5 h-5 mr-2 z-10">{icon}</span>
      <span className="font-semibold tracking-wider z-10 whitespace-nowrap text-xs sm:text-sm">{label}</span>
    </button>
  );
};

export default TabButton;