import React from 'react';

export const BrainCircuit: React.FC = () => (
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <path d="M12 2a2.5 2.5 0 0 0-2.5 2.5v.5a2.5 2.5 0 0 0 5 0v-.5A2.5 2.5 0 0 0 12 2z" />
    <path d="M12 15a2.5 2.5 0 0 0-2.5 2.5v.5a2.5 2.5 0 0 0 5 0v-.5A2.5 2.5 0 0 0 12 15z" />
    <path d="M5 12a2.5 2.5 0 0 0-2.5 2.5v.5a2.5 2.5 0 0 0 5 0v-.5A2.5 2.5 0 0 0 5 12z" />
    <path d="M19 12a2.5 2.5 0 0 0-2.5 2.5v.5a2.5 2.5 0 0 0 5 0v-.5A2.5 2.5 0 0 0 19 12z" />
    <path d="M12 5v2" />
    <path d="M12 13v2" />
    <path d="M7.5 14.5h2" />
    <path d="M14.5 14.5h2" />
    <path d="m16 8-1.9 1.9" />
    <path d="m8 8 1.9 1.9" />
    <path d="m14.1 11.9.8.8" />
    <path d="m7.1 11.9-.8.8" />
  </svg>
);

export const Dna: React.FC = () => (
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <path d="M4 14.5A3.5 3.5 0 0 1 7.5 11H10V7" />
    <path d="M14 7v4h2.5A3.5 3.5 0 0 1 20 14.5" />
    <path d="M4 9.5A3.5 3.5 0 0 0 7.5 13H10v4" />
    <path d="M14 17v-4h2.5A3.5 3.5 0 0 0 20 9.5" />
  </svg>
);

{/* FIX: Add className prop to allow styling */}
export const Disc: React.FC<{className?: string}> = ({className}) => (
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}>
    <circle cx="12" cy="12" r="10" />
    <circle cx="12" cy="12" r="3" />
  </svg>
);

{/* FIX: Add className prop to allow styling */}
export const Radio: React.FC<{className?: string}> = ({className}) => (
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}>
    <path d="M4.5 16.5c-2.1 2.1-2.1 5.6 0 7.7 2.1 2.1 5.6 2.1 7.7 0" />
    <path d="M19.5 12c-2.1 2.1-2.1 5.6 0 7.7 2.1 2.1 5.6 2.1 7.7 0l-7.7-7.7" />
    <path d="M11.8 11.8 19.5 19.5" />
    <path d="M19.5 4.5c2.1-2.1 5.6-2.1 7.7 0l-7.7 7.7c-2.1 2.1-5.6 2.1-7.7 0" />
    <path d="M12.2 12.2 4.5 4.5" />
    <path d="M4.5 12c2.1-2.1 5.6-2.1 7.7 0l-7.7 7.7c-2.1-2.1-2.1-5.6 0-7.7" />
  </svg>
);

export const Play: React.FC<{className?: string}> = ({className}) => (
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className={className}>
    <path d="M8 5v14l11-7z" />
  </svg>
);

export const Pause: React.FC<{className?: string}> = ({className}) => (
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className={className}>
    <path d="M6 19h4V5H6v14zm8-14v14h4V5h-4z" />
  </svg>
);

export const Download: React.FC<{className?: string}> = ({className}) => (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}>
        <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" />
        <polyline points="7 10 12 15 17 10" />
        <line x1="12" y1="15" x2="12" y2="3" />
    </svg>
);

export const Trash: React.FC<{className?: string}> = ({className}) => (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}>
        <polyline points="3 6 5 6 21 6" />
        <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2" />
    </svg>
);

export const Lotus: React.FC = () => (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <path d="M8.5 18a3.5 3.5 0 0 1 7 0" />
        <path d="M8.5 14.5A3.5 3.5 0 0 1 12 11a3.5 3.5 0 0 1 3.5 3.5" />
        <path d="M2 14.5a3.5 3.5 0 0 1 3.5-3.5h.5a3.5 3.5 0 0 1 3.5 3.5" />
        <path d="M22 14.5a3.5 3.5 0 0 0-3.5-3.5h-.5a3.5 3.5 0 0 0-3.5 3.5" />
        <path d="M8.5 11A3.5 3.5 0 0 0 12 7.5a3.5 3.5 0 0 0 3.5 3.5" />
        <path d="M12 7.5V2" />
    </svg>
);

export const Atom: React.FC = () => (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <circle cx="12" cy="12" r="1" />
        <path d="M20.2 20.2c2.04-2.03.02-5.91-2.42-8.35-2.55-2.55-6.33-4.47-8.35-2.42" />
        <path d="M3.8 3.8c-2.04 2.03-.02 5.91 2.42 8.35 2.55 2.55 6.33 4.47 8.35 2.42" />
        <path d="M20.2 3.8c-2.03-2.04-5.91.02-8.35 2.42-2.55 2.55-4.47 6.33-2.42 8.35" />
        <path d="M3.8 20.2c2.03 2.04 5.91-.02 8.35-2.42 2.55-2.55 4.47-6.33 2.42-8.35" />
    </svg>
);

export const BookOpen: React.FC = () => (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <path d="M2 3h6a4 4 0 0 1 4 4v14a3 3 0 0 0-3-3H2z" />
        <path d="M22 3h-6a4 4 0 0 0-4 4v14a3 3 0 0 1 3-3h7z" />
    </svg>
);

export const ToggleSwitch: React.FC<{on: boolean}> = ({on}) => (
    <div className={`w-14 h-8 flex items-center rounded-full p-1 duration-300 ease-in-out ${on ? 'bg-brand-primary' : 'bg-brand-surface'}`}>
        <div className={`bg-brand-bg w-6 h-6 rounded-full shadow-md transform duration-300 ease-in-out ${on ? 'translate-x-6' : ''}`}></div>
    </div>
);