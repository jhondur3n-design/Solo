import React from 'react';
import { Download, Trash } from './Icons';

interface AudioPlayerProps {
  url: string;
  fileName: string;
  onClear: () => void;
}

const AudioPlayer: React.FC<AudioPlayerProps> = ({ url, fileName, onClear }) => {
  const handleDownload = () => {
    const a = document.createElement('a');
    a.style.display = 'none';
    a.href = url;
    a.download = fileName;
    document.body.appendChild(a);
    a.click();
    a.remove();
  };

  return (
    <div className="mt-4 bg-brand-bg/50 p-3 border-t-2 border-brand-accent/80 animate-fade-in">
      <h3 className="font-semibold text-lg text-brand-accent tracking-wider mb-3">[Output] System Render</h3>
      <audio controls src={url} className="w-full"></audio>
      <div className="flex gap-4 mt-4">
        <button onClick={handleDownload} className="flex-1 flex items-center justify-center bg-brand-secondary text-white font-bold py-2 px-4 transition-colors duration-300 tracking-wider hover:bg-brand-secondary/80">
          <Download className="w-5 h-5 mr-2" />
          DOWNLOAD
        </button>
        <button onClick={onClear} className="flex-1 flex items-center justify-center bg-red-600 text-white font-bold py-2 px-4 transition-colors duration-300 tracking-wider hover:bg-red-500">
          <Trash className="w-5 h-5 mr-2" />
          CLEAR
        </button>
      </div>
    </div>
  );
};

export default AudioPlayer;
