import React, { useState, useRef } from 'react';
import { UIAudioTrack, ProcessingProgress } from '../types';
import { Trash } from '../components/Icons';
import { bufferToWave } from '../utils/audio';
import AudioPlayer from '../components/AudioPlayer';

// Create a single, persistent AudioContext
const audioContext = new (window.AudioContext || (window as any).webkitAudioContext)();

const SubliminalMaker: React.FC = () => {
    const [affirmationTracks, setAffirmationTracks] = useState<UIAudioTrack[]>([]);
    const [backgroundTrack, setBackgroundTrack] = useState<UIAudioTrack | null>(null);
    const [isRecording, setIsRecording] = useState(false);
    const [progress, setProgress] = useState<ProcessingProgress>({ status: 'idle', message: 'Awaiting command.' });
    const [outputUrl, setOutputUrl] = useState<string | null>(null);
    const [outputFilename, setOutputFilename] = useState('');
    
    // Configs
    const [layeringMethod, setLayeringMethod] = useState<'masked' | 'silent' | 'audible'>('masked');
    const [affirmationVolume, setAffirmationVolume] = useState(75);
    const [backgroundVolume, setBackgroundVolume] = useState(50);

    const mediaRecorderRef = useRef<MediaRecorder | null>(null);
    const recordedChunksRef = useRef<Blob[]>([]);
    const outputUrlRef = useRef<string>('');

    const handleFileChange = async (event: React.ChangeEvent<HTMLInputElement>, type: 'affirmation' | 'background') => {
        const file = event.target.files?.[0];
        if (!file || !audioContext) return;

        try {
            const arrayBuffer = await file.arrayBuffer();
            const audioBuffer = await audioContext.decodeAudioData(arrayBuffer);
            const newTrack: UIAudioTrack = {
                id: `${Date.now()}-${file.name}`,
                name: file.name,
                buffer: audioBuffer,
            };
            if (type === 'affirmation') {
                setAffirmationTracks(prev => [...prev, newTrack]);
            } else {
                setBackgroundTrack(newTrack);
            }
        } catch (error) {
            console.error('Error decoding audio file:', error);
            setProgress({ status: 'error', message: 'Error decoding audio file.' });
        }
    };
    
    const handleRecordToggle = async () => {
        if (isRecording) {
            mediaRecorderRef.current?.stop();
            setIsRecording(false);
        } else {
            try {
                const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
                mediaRecorderRef.current = new MediaRecorder(stream);
                recordedChunksRef.current = [];
                
                mediaRecorderRef.current.ondataavailable = (event) => {
                    recordedChunksRef.current.push(event.data);
                };

                mediaRecorderRef.current.onstop = async () => {
                    const blob = new Blob(recordedChunksRef.current, { type: 'audio/wav' });
                    const arrayBuffer = await blob.arrayBuffer();
                    const audioBuffer = await audioContext.decodeAudioData(arrayBuffer);
                    const newTrack: UIAudioTrack = {
                        id: `rec-${Date.now()}`,
                        name: `Recording-${new Date().toLocaleTimeString()}.wav`,
                        buffer: audioBuffer
                    };
                    setAffirmationTracks(prev => [...prev, newTrack]);
                    stream.getTracks().forEach(track => track.stop()); // Release microphone
                };
                
                mediaRecorderRef.current.start();
                setIsRecording(true);

            } catch(err) {
                console.error("Microphone access denied:", err);
                setProgress({status: 'error', message: "Microphone access denied."});
            }
        }
    };

    const removeTrack = (id: string) => {
        setAffirmationTracks(tracks => tracks.filter(t => t.id !== id));
    };
    
    const handleClearOutput = () => {
        if (outputUrlRef.current) {
            window.URL.revokeObjectURL(outputUrlRef.current);
            outputUrlRef.current = '';
        }
        setOutputUrl(null);
        setOutputFilename('');
        setProgress({ status: 'idle', message: 'Awaiting command.' });
    };

    const handleExport = async () => {
        if (affirmationTracks.length === 0) {
            setProgress({ status: 'error', message: 'Add at least one affirmation track.' });
            return;
        }
        handleClearOutput();
        setProgress({ status: 'processing', message: 'Initializing audio matrix...' });

        let maxLength = 0;
        affirmationTracks.forEach(t => { if (t.buffer.length > maxLength) maxLength = t.buffer.length; });
        if (backgroundTrack && backgroundTrack.buffer.length > maxLength) {
            maxLength = backgroundTrack.buffer.length;
        }
        
        const offlineCtx = new OfflineAudioContext(2, maxLength, audioContext.sampleRate);

        // Schedule Affirmations
        affirmationTracks.forEach((track, index) => {
            setProgress({ status: 'processing', message: `Processing affirmation ${index + 1}/${affirmationTracks.length}` });
            const source = offlineCtx.createBufferSource();
            source.buffer = track.buffer;

            if (layeringMethod === 'silent') {
                // Amplitude Modulation for "Ultrasonic" effect
                const carrier = offlineCtx.createOscillator();
                carrier.frequency.value = 17500; // Ultrasonic frequency
                
                const modulator = offlineCtx.createBufferSource();
                modulator.buffer = track.buffer;
                
                const modulationGain = offlineCtx.createGain();
                modulationGain.gain.value = affirmationVolume / 100;

                const depth = offlineCtx.createGain();
                depth.gain.value = 0.5;

                modulator.connect(depth);
                depth.connect(modulationGain.gain);
                carrier.connect(modulationGain);
                modulationGain.connect(offlineCtx.destination);
                carrier.start();
                modulator.start();

            } else {
                 const gainNode = offlineCtx.createGain();
                 gainNode.gain.value = layeringMethod === 'masked' ? 0.08 * (affirmationVolume / 100) : affirmationVolume / 100; // Lower volume for masked
                 source.connect(gainNode);
                 gainNode.connect(offlineCtx.destination);
                 source.start();
            }
        });

        // Schedule Background
        if (backgroundTrack) {
            setProgress({ status: 'processing', message: 'Layering background audio...' });
            const source = offlineCtx.createBufferSource();
            source.buffer = backgroundTrack.buffer;
            source.loop = true;
            const gainNode = offlineCtx.createGain();
            gainNode.gain.value = backgroundVolume / 100;
            source.connect(gainNode);
            gainNode.connect(offlineCtx.destination);
            source.start();
        }

        try {
            setProgress({ status: 'processing', message: 'Rendering final output... This may take a moment.' });
            const renderedBuffer = await offlineCtx.startRendering();
            const wavBlob = bufferToWave(renderedBuffer);
            
            const url = URL.createObjectURL(wavBlob);
            outputUrlRef.current = url;
            setOutputUrl(url);
            setOutputFilename(`subliminal-session-${Date.now()}.wav`);
            setProgress({ status: 'done', message: 'Export complete. Preview is ready.' });
        } catch (error) {
            console.error('Error rendering audio:', error);
            setProgress({ status: 'error', message: 'An error occurred during export.' });
        }
    };


    return (
        <div className="animate-fade-in">
            <h2 className="text-2xl font-bold text-brand-primary mb-1 tracking-widest">[MODULE] SUBLIMINAL CREATION</h2>
            <p className="mb-4 text-brand-text-dark border-b-2 border-brand-primary/20 pb-2">Craft custom subliminal sessions. All processing is executed locally.</p>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                
                {/* Affirmations Panel */}
                <div className="bg-brand-bg/50 p-3 border border-brand-primary/20 space-y-3">
                    <h3 className="font-semibold text-lg text-brand-primary tracking-wider">[Log] Affirmation Tracks</h3>
                    <div className="space-y-2 max-h-40 overflow-y-auto pr-2">
                        {affirmationTracks.length > 0 ? affirmationTracks.map(track => (
                            <div key={track.id} className="flex items-center justify-between bg-brand-surface p-2 text-sm">
                                <span className="truncate flex-1 mr-2">{track.name}</span>
                                <button onClick={() => removeTrack(track.id)} className="text-red-500 hover:text-red-400"><Trash className="w-4 h-4" /></button>
                            </div>
                        )) : <p className="text-sm text-brand-text-dark">No affirmation tracks added.</p>}
                    </div>
                    <div className="flex flex-wrap gap-2">
                         <button onClick={handleRecordToggle} className={`flex-1 border-2 font-bold py-2 px-4 transition-colors duration-300 tracking-wider ${isRecording ? 'bg-red-500 border-red-500 text-white animate-pulse' : 'bg-transparent border-brand-secondary text-brand-secondary hover:bg-brand-secondary hover:text-brand-bg'}`}>
                            {isRecording ? 'STOP RECORDING' : 'RECORD VOICE'}
                         </button>
                    </div>
                    <div>
                        <label htmlFor="affirm-upload" className="text-sm text-brand-text-dark block mb-1">UPLOAD AFFIRMATION AUDIO</label>
                        <input id="affirm-upload" type="file" accept="audio/*" onChange={(e) => handleFileChange(e, 'affirmation')} className="w-full text-sm text-brand-text-dark file:mr-4 file:py-2 file:px-4 file:rounded-none file:border-2 file:border-brand-accent/50 file:text-sm file:font-semibold file:bg-transparent file:text-brand-accent hover:file:bg-brand-accent hover:file:text-brand-bg transition-colors duration-300 cursor-pointer"/>
                    </div>
                </div>

                {/* Background Panel */}
                <div className="bg-brand-bg/50 p-3 border border-brand-primary/20 space-y-3">
                    <h3 className="font-semibold text-lg text-brand-primary tracking-wider">[System] Background Audio</h3>
                    {backgroundTrack && <p className="text-sm text-brand-text-dark bg-brand-surface p-2">Current: <span className="text-brand-text">{backgroundTrack.name}</span></p>}
                     <div>
                        <label htmlFor="bg-upload" className="text-sm text-brand-text-dark block mb-1">UPLOAD BACKGROUND AUDIO</label>
                        <input id="bg-upload" type="file" accept="audio/*" onChange={(e) => handleFileChange(e, 'background')} className="w-full text-sm text-brand-text-dark file:mr-4 file:py-2 file:px-4 file:rounded-none file:border-2 file:border-brand-accent/50 file:text-sm file:font-semibold file:bg-transparent file:text-brand-accent hover:file:bg-brand-accent hover:file:text-brand-bg transition-colors duration-300 cursor-pointer"/>
                    </div>
                    <label className="block text-sm font-medium text-brand-text-dark tracking-wider">BACKGROUND VOLUME: {backgroundVolume}%</label>
                    <input type="range" min="0" max="100" value={backgroundVolume} onChange={e => setBackgroundVolume(Number(e.target.value))} className="w-full h-2 bg-brand-primary/30 rounded-lg appearance-none cursor-pointer accent-brand-primary" />
                </div>
                
                {/* Settings Panel */}
                <div className="bg-brand-bg/50 p-3 border border-brand-primary/20 lg:col-span-2">
                    <h3 className="font-semibold text-lg text-brand-primary mb-3 tracking-wider">[System] Parameters</h3>
                     <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                            <label className="block text-sm font-medium text-brand-text-dark tracking-wider">LAYERING METHOD</label>
                            <select value={layeringMethod} onChange={e => setLayeringMethod(e.target.value as any)} className="w-full mt-1 p-2 bg-brand-surface border-2 border-brand-primary/30 rounded-none focus:border-brand-primary focus:ring-0">
                              <option value="masked">Masked</option>
                              <option value="silent">Silent (Ultrasonic)</option>
                              <option value="audible">Audible</option>
                            </select>
                        </div>
                         <div>
                            <label className="block text-sm font-medium text-brand-text-dark tracking-wider">AFFIRMATION VOLUME: {affirmationVolume}%</label>
                             <input type="range" min="0" max="100" value={affirmationVolume} onChange={e => setAffirmationVolume(Number(e.target.value))} className="w-full h-2 mt-1 bg-brand-primary/30 rounded-lg appearance-none cursor-pointer accent-brand-primary" />
                        </div>
                    </div>
                </div>

                 {/* Export Panel */}
                <div className="bg-brand-surface p-3 border-2 border-brand-accent/80 lg:col-span-2">
                    <div className="flex flex-col md:flex-row items-center justify-between gap-4">
                        <p className={`font-semibold tracking-wider ${progress.status === 'error' ? 'text-red-500' : 'text-brand-accent'}`}>
                            {progress.status === 'processing' && <span className="animate-pulse">SYSTEM BUSY: </span>}
                            {progress.message}
                        </p>
                        <button onClick={handleExport} disabled={progress.status === 'processing'} className="w-full md:w-auto bg-brand-accent text-brand-bg font-bold py-3 px-8 transition-all duration-300 tracking-widest text-lg hover:shadow-glow hover:shadow-brand-accent/50 disabled:bg-gray-500 disabled:cursor-not-allowed disabled:shadow-none">
                          {progress.status === 'processing' ? 'PROCESSING...' : 'INITIATE EXPORT'}
                        </button>
                    </div>
                </div>

                {outputUrl && (
                    <div className="lg:col-span-2">
                        <AudioPlayer 
                            url={outputUrl} 
                            fileName={outputFilename}
                            onClear={handleClearOutput} 
                        />
                    </div>
                )}
            </div>
        </div>
    );
};

export default SubliminalMaker;