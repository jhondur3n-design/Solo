import React, { useState } from 'react';

const instructionsData = [
    {
        id: 'general',
        title: 'General Operation & Offline Use',
        content: (
            <>
                <p>Welcome, Operator. This system is a fully self-contained, offline-capable suite of tools for personal transformation. All processing is done locally on your device; no data ever leaves your machine.</p>
                <p className="mt-2"><strong>Offline Capability:</strong> After your first visit, the entire application is cached. You can use it anywhere, anytime, without an internet connection, ensuring complete privacy and availability.</p>
                <p className="mt-2"><strong>Installation:</strong> For the best experience, install this application to your device using the "[INSTALL APP]" button in the main menu. This will add it to your home screen or desktop like a native app.</p>
            </>
        )
    },
    {
        id: 'subliminalMaker',
        title: 'Subliminal Creation',
        content: (
            <>
                <p>This module allows you to embed affirmations into a background track, making them perceptible only to the subconscious mind.</p>
                <ul className="list-disc list-inside mt-2 space-y-1">
                    <li><strong>Affirmation Tracks:</strong> Record your own voice or upload pre-recorded audio files containing your affirmations. You can add multiple tracks.</li>
                    <li><strong>Background Audio:</strong> Upload a single audio file (e.g., music, nature sounds, white noise) to mask the affirmations.</li>
                    <li><strong>Layering Method:</strong>
                        <ul className="list-['-_'] list-inside ml-4">
                            <li><strong>Masked:</strong> The standard method. Affirmations are audible but buried just below the conscious hearing threshold of the background track.</li>
                            <li><strong>Silent (Ultrasonic):</strong> Affirmations are modulated to a very high frequency (approx. 17.5kHz), making them inaudible to most adults but still processable by the brain.</li>
                            <li><strong>Audible:</strong> A simple audio mixer. Both affirmations and background will be clearly audible at their set volumes.</li>
                        </ul>
                    </li>
                     <li><strong>Export & Preview:</strong> After processing, an audio player will appear, allowing you to preview the final track before downloading.</li>
                </ul>
            </>
        )
    },
    {
        id: 'amplifier',
        title: 'Energetic Amplifier',
        content: (
            <>
                <p>Energize and empower audio by enhancing its dynamic texture and stereo presence without simply making it louder.</p>
                <ul className="list-disc list-inside mt-2 space-y-1">
                    <li><strong>Load Audio:</strong> Begin by uploading the audio file you wish to enhance.</li>
                    <li><strong>Dynamic Cohesion:</strong> Brings forth subtle details and creates a denser, more unified sound.</li>
                    <li><strong>Harmonic Resonance:</strong> Adds richness and warmth by introducing subtle harmonic overtones.</li>
                    <li><strong>Stereo Field Expansion:</strong> Widens the audio's presence for a more immersive, holographic experience.</li>
                    <li><strong>Subtle Clarity:</strong> Enhances high-frequency details for a crisper, more defined sound.</li>
                </ul>
            </>
        )
    },
    {
        id: 'radionics',
        title: 'Radionics',
        content: (
            <>
                <p>This module is a digital radionics instrument for focusing and broadcasting intention into the quantum field.</p>
                <ul className="list-disc list-inside mt-2 space-y-1">
                    <li><strong>Intention Field:</strong> Clearly type your desired outcome or goal. Be specific and positive.</li>
                    <li><strong>Target Sigil:</strong> Upload an image representing your goal (a sigil, a photo, a symbol). This acts as a visual anchor for the energy.</li>
                    <li><strong>Power Level:</strong> Controls the amplitude and intensity of the carrier wave. Higher levels mean a stronger broadcast.</li>
                    <li><strong>Energetic Signature:</strong> Adjusts the 'rate' or frequency of the broadcast, fine-tuning it to your specific intention. Treat this as a "dial" to find what feels right.</li>
                    <li><strong>Operation:</strong> The system will first 'Analyze' your inputs to lock onto the intention, then begin the 'Broadcast'. A subtle, layered hum indicates active transmission.</li>
                </ul>
            </>
        )
    },
    {
        id: 'frequencies',
        title: 'Frequency Generator',
        content: (
            <>
                <p>Generate pure audio tones for meditation, focus, and altering states of consciousness.</p>
                <ul className="list-disc list-inside mt-2 space-y-1">
                    <li><strong>Solfeggio:</strong> Ancient, sacred tones used for healing and spiritual development. Each frequency corresponds to a specific aspect of being.</li>
                    <li><strong>Binaural Beats:</strong> Requires headphones. Two slightly different frequencies are played in each ear, and the brain creates a third 'beat' frequency inside your head, encouraging specific brainwave states (e.g., relaxation, focus).</li>
                    <li><strong>Isochronic Tones:</strong> A single tone that is rapidly turned on and off. This creates a distinct, rhythmic pulse that can also be used to guide brainwave entrainment. Does not require headphones.</li>
                </ul>
            </>
        )
    },
    {
        id: 'chakra',
        title: 'Chakra Attunement',
        content: (
            <>
                <p>This module uses specific Solfeggio frequencies to target, balance, and align the seven primary energy centers (chakras) of the body.</p>
                <ul className="list-disc list-inside mt-2 space-y-1">
                    <li><strong>Selection:</strong> Choose a chakra from the list to view its name, purpose, and associated frequency.</li>
                    <li><strong>Attunement:</strong> Press 'PLAY' to generate the pure tone for the selected chakra. The orb will glow and pulse, indicating that the frequency is active.</li>
                    <li><strong>Usage:</strong> Use these tones during meditation. Focus your attention on the corresponding area of your body and visualize the chakra's color as you listen.</li>
                </ul>
            </>
        )
    },
    {
        id: 'quantum',
        title: 'Quantum Healing',
        content: (
            <>
                <p>An immersive experience designed to harmonize your bio-field by interfacing with the zero-point energy of the quantum field.</p>
                <ul className="list-disc list-inside mt-2 space-y-1">
                    <li><strong>Healing Focus:</strong> Enter your intention for the session. This could be physical, emotional, or spiritual.</li>
                    <li><strong>Session Duration:</strong> Select the length of your session. The system will automatically fade out when the time is complete.</li>
                    <li><strong>The Session:</strong> When you begin, the module generates a complex soundscape combining a grounding drone, pink noise, and other harmonic elements. The visuals and audio work together to create a powerful environment for healing and realignment. Simply relax, close your eyes, and allow the process to unfold.</li>
                </ul>
            </>
        )
    }
];

const AccordionItem: React.FC<{ title: string, content: React.ReactNode, isOpen: boolean, onClick: () => void }> = ({ title, content, isOpen, onClick }) => {
    return (
        <div className="border-b-2 border-brand-primary/20">
            <button onClick={onClick} className="w-full text-left p-3 flex justify-between items-center hover:bg-brand-primary/10">
                <h3 className="font-semibold text-lg text-brand-primary tracking-wider">{title}</h3>
                <span className={`transform transition-transform duration-300 text-brand-primary ${isOpen ? 'rotate-180' : 'rotate-0'}`}>▼</span>
            </button>
            <div className={`overflow-hidden transition-all duration-500 ease-in-out ${isOpen ? 'max-h-[30rem]' : 'max-h-0'}`}>
                <div className="p-4 bg-brand-bg/30 text-brand-text-dark space-y-2">
                    {content}
                </div>
            </div>
        </div>
    );
};

const Instructions: React.FC = () => {
    const [openAccordion, setOpenAccordion] = useState<string | null>('general');
    
    const handleToggle = (id: string) => {
        setOpenAccordion(openAccordion === id ? null : id);
    };

    return (
        <div className="animate-fade-in">
            <h2 className="text-2xl font-bold text-brand-primary mb-1 tracking-widest">[SYSTEM] OPERATOR'S MANUAL</h2>
            <p className="mb-4 text-brand-text-dark border-b-2 border-brand-primary/20 pb-2">Detailed instructions for all system modules.</p>
            
            <div className="space-y-2">
                {instructionsData.map(item => (
                    <AccordionItem 
                        key={item.id}
                        title={item.title}
                        content={item.content}
                        isOpen={openAccordion === item.id}
                        onClick={() => handleToggle(item.id)}
                    />
                ))}
            </div>
        </div>
    );
};

export default Instructions;
