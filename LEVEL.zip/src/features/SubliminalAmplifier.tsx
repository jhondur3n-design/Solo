import React, { useState, useRef } from 'react';
import { UIAudioTrack, ProcessingProgress } from '../types';
import { BrainCircuit } from '../components/Icons';
import { bufferToWave } from '../utils/audio';
import AudioPlayer from '../components/AudioPlayer';

const audioContext = new (window.AudioContext || (window as any).webkitAudioContext)();

// Calculates the Root Mean Square of an AudioBuffer to measure its average power.
const calculateRMS = (buffer: AudioBuffer): number => {
    let totalRms = 0;
    for (let i = 0; i < buffer.numberOfChannels; i++) {
        const data = buffer.getChannelData(i);
        let sumOfSquares = 0;
        for (let j = 0; j < data.length; j++) {
            sumOfSquares += data[j] * data[j];
        }
        totalRms += Math.sqrt(sumOfSquares / data.length);
    }
    return totalRms / buffer.numberOfChannels;
};


const SubliminalAmplifier: React.FC = () => {
    const [sourceTrack, setSourceTrack] = useState<UIAudioTrack | null>(null);
    const [progress, setProgress] = useState<ProcessingProgress>({ status: 'idle', message: 'Load an audio track to begin.' });
    const [outputUrl, setOutputUrl] = useState<string | null>(null);
    
    // New enhancement parameters
    const [cohesion, setCohesion] = useState(0); // 0-100
    const [resonance, setResonance] = useState(0); // 0-100
    const [expansion, setExpansion] = useState(0); // 0-100
    const [clarity, setClarity] = useState(0); // 0-100
    
    const outputUrlRef = useRef<string>('');

    const handleFileChange = async (event: React.ChangeEvent<HTMLInputElement>) => {
        const file = event.target.files?.[0];
        if (!file || !audioContext) return;
        handleClearOutput();
        try {
            setProgress({ status: 'processing', message: 'Decoding audio...' });
            const arrayBuffer = await file.arrayBuffer();
            const audioBuffer = await audioContext.decodeAudioData(arrayBuffer);
            setSourceTrack({
                id: `${Date.now()}-${file.name}`,
                name: file.name,
                buffer: audioBuffer,
            });
            setProgress({ status: 'idle', message: `${file.name} loaded successfully.` });
        } catch (error) {
            console.error('Error decoding audio file:', error);
            setProgress({ status: 'error', message: 'Error decoding audio file.' });
        }
    };

    const makeDistortionCurve = (amount: number) => {
        const k = amount * 1.5; // Scale for more subtle effect
        const n_samples = 44100;
        const curve = new Float32Array(n_samples);
        const deg = Math.PI / 180;
        for (let i = 0; i < n_samples; ++i ) {
            const x = i * 2 / n_samples - 1;
            curve[i] = ( 3 + k ) * x * 20 * deg / ( Math.PI + k * Math.abs(x) );
        }
        return curve;
    };
    
    const handleClearOutput = () => {
        if (outputUrlRef.current) {
            window.URL.revokeObjectURL(outputUrlRef.current);
            outputUrlRef.current = '';
        }
        setOutputUrl(null);
        if(sourceTrack) {
            setProgress({ status: 'idle', message: `${sourceTrack.name} loaded.` });
        } else {
            setProgress({ status: 'idle', message: 'Load an audio track to begin.' });
        }
    };

    const handleExport = async () => {
        if (!sourceTrack) {
            setProgress({ status: 'error', message: 'No source track loaded.' });
            return;
        }
        handleClearOutput();
        setProgress({ status: 'processing', message: 'Analyzing source audio...' });

        const originalRms = calculateRMS(sourceTrack.buffer);

        const offlineCtx = new OfflineAudioContext(sourceTrack.buffer.numberOfChannels, sourceTrack.buffer.length, sourceTrack.buffer.sampleRate);

        const source = offlineCtx.createBufferSource();
        source.buffer = sourceTrack.buffer;
        let lastNode: AudioNode = source;

        // 1. Dynamic Cohesion (Compressor)
        if (cohesion > 0) {
            setProgress({ status: 'processing', message: 'Applying Cohesion...' });
            const compressor = offlineCtx.createDynamicsCompressor();
            compressor.threshold.value = -1 - (cohesion / 100) * 49; // -1 to -50
            compressor.ratio.value = 1 + (cohesion / 100) * 11; // 1 to 12
            compressor.attack.value = 0.01;
            compressor.release.value = 0.25;
            lastNode.connect(compressor);
            lastNode = compressor;
        }

        // 2. Harmonic Resonance (Waveshaper)
        if (resonance > 0) {
             setProgress({ status: 'processing', message: 'Adding Resonance...' });
            const distortion = offlineCtx.createWaveShaper();
            distortion.curve = makeDistortionCurve(resonance);
            distortion.oversample = '4x';
            lastNode.connect(distortion);
            lastNode = distortion;
        }
        
        // 3. Subtle Clarity (High-shelf Filter)
        if (clarity > 0) {
            setProgress({ status: 'processing', message: 'Enhancing Clarity...' });
            const clarityFilter = offlineCtx.createBiquadFilter();
            clarityFilter.type = 'highshelf';
            clarityFilter.frequency.value = 6000;
            clarityFilter.gain.value = (clarity / 100) * 6; // 0 to 6dB boost
            lastNode.connect(clarityFilter);
            lastNode = clarityFilter;
        }

        // 4. Stereo Field Expansion (Mid-Side Processing)
        if (expansion > 0 && sourceTrack.buffer.numberOfChannels === 2) {
             setProgress({ status: 'processing', message: 'Expanding Stereo Field...' });
            const splitter = offlineCtx.createChannelSplitter(2);
            const merger = offlineCtx.createChannelMerger(2);
            const midGain = offlineCtx.createGain();
            const sideGain = offlineCtx.createGain();
            const L_plus_R = offlineCtx.createGain();
            const L_minus_R = offlineCtx.createGain();
            const inverter = offlineCtx.createGain(); inverter.gain.value = -1;

            lastNode.connect(splitter);
            splitter.connect(L_plus_R, 0); splitter.connect(L_plus_R, 1);
            splitter.connect(L_minus_R, 0); splitter.connect(inverter, 1); inverter.connect(L_minus_R);

            L_plus_R.connect(midGain);
            L_minus_R.connect(sideGain);
            
            sideGain.gain.value = 1 + (expansion / 100) * 2; // 1 to 3

            const inverter2 = offlineCtx.createGain(); inverter2.gain.value = -1;
            midGain.connect(merger, 0, 0); sideGain.connect(merger, 0, 0);
            midGain.connect(merger, 0, 1); sideGain.connect(inverter2).connect(merger, 0, 1);

            lastNode = merger;
        }
        
        lastNode.connect(offlineCtx.destination);
        source.start();

        try {
            setProgress({ status: 'processing', message: 'Rendering energized audio...' });
            const renderedBuffer = await offlineCtx.startRendering();
            
            // 5. Loudness Normalization
            setProgress({ status: 'processing', message: 'Normalizing loudness...' });
            const newRms = calculateRMS(renderedBuffer);
            if (newRms > 0) {
                const gainCorrection = originalRms / newRms;
                 if (isFinite(gainCorrection)) {
                    for (let i = 0; i < renderedBuffer.numberOfChannels; i++) {
                        const channelData = renderedBuffer.getChannelData(i);
                        for (let j = 0; j < channelData.length; j++) {
                            channelData[j] *= gainCorrection;
                        }
                    }
                }
            }

            const wavBlob = bufferToWave(renderedBuffer);
            const url = URL.createObjectURL(wavBlob);
            outputUrlRef.current = url;
            setOutputUrl(url);
            setProgress({ status: 'done', message: 'Amplification complete. Preview ready.' });
        } catch (error) {
            console.error('Error rendering audio:', error);
            setProgress({ status: 'error', message: 'An error occurred during export.' });
        }
    };
    
    const ParameterSlider: React.FC<{label: string, value: number, onChange: (v: number) => void, description: string }> = 
    ({ label, value, onChange, description }) => (
        <div>
            <label className="block text-sm font-medium text-brand-text-dark tracking-wider">{label}: {value}%</label>
            <input type="range" min={0} max={100} step="1" value={value} onChange={e => onChange(Number(e.target.value))} className="w-full h-2 mt-1 bg-brand-primary/30 rounded-lg appearance-none cursor-pointer accent-brand-primary" />
            <p className="text-xs text-brand-text-dark/70 mt-1">{description}</p>
        </div>
    );

    return (
        <div className="animate-fade-in">
            <h2 className="text-2xl font-bold text-brand-primary mb-1 tracking-widest">[MODULE] ENERGETIC AMPLIFIER</h2>
            <p className="mb-4 text-brand-text-dark border-b-2 border-brand-primary/20 pb-2">Energize and empower audio by enhancing its dynamic texture and stereo presence without increasing loudness.</p>

            <div className="space-y-4">
                <div className="bg-brand-bg/50 p-3 border border-brand-primary/20">
                    <h3 className="font-semibold text-lg text-brand-primary tracking-wider mb-3">[System] Load Audio</h3>
                    <input type="file" accept="audio/*" onChange={handleFileChange} className="w-full text-sm text-brand-text-dark file:mr-4 file:py-2 file:px-4 file:rounded-none file:border-2 file:border-brand-accent/50 file:text-sm file:font-semibold file:bg-transparent file:text-brand-accent hover:file:bg-brand-accent hover:file:text-brand-bg transition-colors duration-300 cursor-pointer"/>
                    {sourceTrack && <p className="text-sm text-brand-text mt-3 bg-brand-surface p-2">Loaded: <span className="font-semibold">{sourceTrack.name}</span></p>}
                </div>

                {sourceTrack && (
                    <>
                        <div className="bg-brand-bg/50 p-3 border border-brand-primary/20">
                            <h3 className="font-semibold text-lg text-brand-primary tracking-wider mb-4">[Matrix] Enhancement Parameters</h3>
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                               <ParameterSlider label="Dynamic Cohesion" value={cohesion} onChange={setCohesion} description="Brings forth subtle details and creates a denser, more unified sound." />
                               <ParameterSlider label="Harmonic Resonance" value={resonance} onChange={setResonance} description="Adds richness and warmth by introducing subtle harmonic overtones." />
                               <ParameterSlider label="Stereo Field Expansion" value={expansion} onChange={setExpansion} description="Widens the audio's presence for a more immersive experience." />
                               <ParameterSlider label="Subtle Clarity" value={clarity} onChange={setClarity} description="Enhances high-frequency details for a crisper, more defined sound." />
                            </div>
                        </div>
                        
                        <div className="bg-brand-surface p-3 border-2 border-brand-accent/80">
                            <div className="flex flex-col md:flex-row items-center justify-between gap-4">
                                <p className={`font-semibold tracking-wider ${progress.status === 'error' ? 'text-red-500' : 'text-brand-accent'}`}>
                                    {progress.status === 'processing' && <span className="animate-pulse">SYSTEM BUSY: </span>}
                                    {progress.message}
                                </p>
                                <button onClick={handleExport} disabled={progress.status === 'processing'} className="w-full md:w-auto bg-brand-accent text-brand-bg font-bold py-3 px-8 transition-all duration-300 tracking-widest text-lg hover:shadow-glow hover:shadow-brand-accent/50 disabled:bg-gray-500 disabled:cursor-not-allowed disabled:shadow-none">
                                  {progress.status === 'processing' ? 'PROCESSING...' : 'ENERGIZE & EXPORT'}
                                </button>
                            </div>
                        </div>
                        {outputUrl && sourceTrack && (
                            <AudioPlayer 
                                url={outputUrl} 
                                fileName={`energized-${sourceTrack.name}`}
                                onClear={handleClearOutput} 
                            />
                        )}
                    </>
                )}

                {!sourceTrack && (
                     <div className="flex flex-col items-center justify-center text-center p-6 animate-pulse-glow">
                        <div className="w-24 h-24 text-brand-primary/50 mb-6">
                            <BrainCircuit />
                        </div>
                        <p className="text-brand-text-dark">Awaiting audio file input...</p>
                    </div>
                )}
            </div>
        </div>
    );
};

export default SubliminalAmplifier;