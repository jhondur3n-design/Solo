import React, { useState, useRef, useEffect } from 'react';
import { Play, Pause, Disc } from '../components/Icons';

type FrequencyType = 'solfeggio' | 'binaural' | 'isochronic';

const solfeggioFrequencies: { [key: string]: number } = {
    '174 Hz - Foundation': 174,
    '285 Hz - Quantum Cognition': 285,
    '396 Hz - Liberation': 396,
    '417 Hz - Transmutation': 417,
    '528 Hz - Transformation': 528,
    '639 Hz - Connection': 639,
    '741 Hz - Consciousness Expansion': 741,
    '852 Hz - Intuition': 852,
    '963 Hz - Divine Order': 963,
};

const FrequencyGenerator: React.FC = () => {
    const [isPlaying, setIsPlaying] = useState(false);
    const [type, setType] = useState<FrequencyType>('solfeggio');
    const [volume, setVolume] = useState(25); // Percentage
    
    // Parameters
    const [solfeggioKey, setSolfeggioKey] = useState(Object.keys(solfeggioFrequencies)[4]);
    const [carrierFreq, setCarrierFreq] = useState(136.1); // for binaural/isochronic
    const [beatFreq, setBeatFreq] = useState(7.83); // for binaural/isochronic

    const audioContextRef = useRef<AudioContext | null>(null);
    const gainRef = useRef<GainNode | null>(null);
    const sourcesRef = useRef<AudioNode[]>([]);
    
    // Cleanup on component unmount
    useEffect(() => {
        return () => {
            if (isPlaying) {
                stopSound();
            }
        };
    }, [isPlaying]);

    const playSound = () => {
        if (isPlaying) return;
        const ctx = new (window.AudioContext || (window as any).webkitAudioContext)();
        const mainGain = ctx.createGain();
        mainGain.gain.setValueAtTime(volume / 100, ctx.currentTime);
        mainGain.connect(ctx.destination);
        
        let nodes: AudioNode[] = [];

        if (type === 'solfeggio') {
            const osc = ctx.createOscillator();
            osc.type = 'sine';
            osc.frequency.value = solfeggioFrequencies[solfeggioKey];
            osc.connect(mainGain);
            osc.start();
            nodes.push(osc);
        } else if (type === 'binaural') {
            const oscL = ctx.createOscillator();
            const oscR = ctx.createOscillator();
            const merger = ctx.createChannelMerger(2);
            
            oscL.type = 'sine';
            oscL.frequency.value = carrierFreq - beatFreq / 2;
            oscR.type = 'sine';
            oscR.frequency.value = carrierFreq + beatFreq / 2;
            
            oscL.connect(merger, 0, 0);
            oscR.connect(merger, 0, 1);
            merger.connect(mainGain);
            
            oscL.start();
            oscR.start();
            nodes.push(oscL, oscR, merger);
        } else if (type === 'isochronic') {
            const osc = ctx.createOscillator();
            const pulseGain = ctx.createGain();
            const lfo = ctx.createOscillator();
            
            osc.type = 'sine';
            osc.frequency.value = carrierFreq;
            
            lfo.frequency.value = beatFreq;
            lfo.connect(pulseGain.gain);
            
            osc.connect(pulseGain);
            pulseGain.connect(mainGain);
            
            osc.start();
            lfo.start();
            nodes.push(osc, lfo, pulseGain);
        }
        
        audioContextRef.current = ctx;
        gainRef.current = mainGain;
        sourcesRef.current = nodes;
        setIsPlaying(true);
    };

    const stopSound = () => {
        if (!isPlaying || !audioContextRef.current) return;
        audioContextRef.current.close().then(() => {
            audioContextRef.current = null;
            gainRef.current = null;
            sourcesRef.current = [];
            setIsPlaying(false);
        });
    };

    const handlePlayToggle = () => {
        if (isPlaying) {
            stopSound();
        } else {
            playSound();
        }
    };
    
    useEffect(() => {
        if (isPlaying && gainRef.current && audioContextRef.current) {
            gainRef.current.gain.setValueAtTime(volume / 100, audioContextRef.current.currentTime);
        }
    }, [volume, isPlaying]);
    
    useEffect(() => {
        if(isPlaying) {
            stopSound();
        }
    }, [type, solfeggioKey, carrierFreq, beatFreq]);


    const renderControls = () => {
        switch(type) {
            case 'solfeggio':
                return (
                    <div>
                        <label className="block text-sm font-medium text-brand-text-dark tracking-wider">TONE</label>
                        <select value={solfeggioKey} onChange={e => setSolfeggioKey(e.target.value)} className="w-full mt-1 p-2 bg-brand-surface border-2 border-brand-primary/30 rounded-none focus:border-brand-primary focus:ring-0">
                           {Object.keys(solfeggioFrequencies).map(key => <option key={key} value={key}>{key}</option>)}
                        </select>
                    </div>
                );
            case 'binaural':
            case 'isochronic':
                return (
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        <div>
                            <label className="block text-sm font-medium text-brand-text-dark tracking-wider">CARRIER FREQ: {carrierFreq.toFixed(2)} Hz</label>
                            <input type="range" min="20" max="1000" step="0.1" value={carrierFreq} onChange={e => setCarrierFreq(Number(e.target.value))} className="w-full h-2 mt-1 bg-brand-primary/30 rounded-lg appearance-none cursor-pointer accent-brand-primary"/>
                        </div>
                         <div>
                            <label className="block text-sm font-medium text-brand-text-dark tracking-wider">{type === 'binaural' ? 'BEAT FREQ' : 'PULSE RATE'}: {beatFreq.toFixed(2)} Hz</label>
                            <input type="range" min="0.5" max="30" step="0.1" value={beatFreq} onChange={e => setBeatFreq(Number(e.target.value))} className="w-full h-2 mt-1 bg-brand-primary/30 rounded-lg appearance-none cursor-pointer accent-brand-primary"/>
                        </div>
                    </div>
                );
        }
    }

    return (
        <div className="animate-fade-in">
            <h2 className="text-2xl font-bold text-brand-primary mb-1 tracking-widest">[MODULE] FREQUENCIES</h2>
            <p className="mb-4 text-brand-text-dark border-b-2 border-brand-primary/20 pb-2">Generate and amplify powerful audio frequencies.</p>

            <div className="flex flex-col lg:flex-row gap-4">
                {/* Controls */}
                <div className="lg:w-2/3 space-y-4">
                    <div className="bg-brand-bg/50 p-3 border border-brand-primary/20">
                         <h3 className="font-semibold text-lg text-brand-primary tracking-wider mb-3">[System] Tone Selection</h3>
                         <div className="flex space-x-2">
                             {(['solfeggio', 'binaural', 'isochronic'] as FrequencyType[]).map(t => (
                                <button key={t} onClick={() => setType(t)} className={`flex-1 p-2 text-sm font-bold tracking-wider uppercase transition-colors duration-300 border-2 ${type === t ? 'bg-brand-primary text-brand-bg border-brand-primary' : 'bg-transparent text-brand-primary/70 border-brand-primary/30 hover:bg-brand-primary/20'}`}>
                                    {t}
                                </button>
                             ))}
                         </div>
                    </div>
                    <div className="bg-brand-bg/50 p-3 border border-brand-primary/20">
                        <h3 className="font-semibold text-lg text-brand-primary tracking-wider mb-3">[System] Parameters</h3>
                        {renderControls()}
                    </div>
                </div>

                {/* Player */}
                <div className="lg:w-1/3 flex flex-col gap-4">
                    <div className="bg-brand-bg/50 p-3 border border-brand-primary/20 flex-grow flex flex-col items-center justify-center text-center">
                       <Disc className={`w-28 h-28 text-brand-primary transition-all duration-500 ${isPlaying ? 'animate-spin-slow' : ''}`} />
                       <p className="mt-4 text-brand-text-dark">{isPlaying ? 'GENERATING FREQUENCY...' : 'SYSTEM IDLE'}</p>
                    </div>
                     <div className="bg-brand-bg/50 p-3 border border-brand-primary/20">
                        <label className="block text-sm text-center font-medium text-brand-text-dark tracking-wider mb-2">MASTER VOLUME: {volume}%</label>
                        <input type="range" min="0" max="100" value={volume} onChange={e => setVolume(Number(e.target.value))} className="w-full h-2 bg-brand-primary/30 rounded-lg appearance-none cursor-pointer accent-brand-primary"/>
                    </div>
                     <button onClick={handlePlayToggle} className={`w-full flex items-center justify-center p-4 border-2 font-bold tracking-widest text-lg transition-colors duration-300 ${isPlaying ? 'bg-brand-primary text-brand-bg border-brand-primary' : 'bg-transparent text-brand-primary border-brand-primary hover:bg-brand-primary/20'}`}>
                        {isPlaying ? <Pause className="w-6 h-6 mr-3" /> : <Play className="w-6 h-6 mr-3" />}
                        {isPlaying ? 'STOP' : 'PLAY'}
                    </button>
                </div>
            </div>
        </div>
    );
};

export default FrequencyGenerator;
