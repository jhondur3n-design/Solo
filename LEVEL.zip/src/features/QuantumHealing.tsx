import React, { useState, useRef, useEffect, useCallback } from 'react';

const QuantumHealing: React.FC = () => {
    const [duration, setDuration] = useState(300); // 5 minutes in seconds
    const [timeLeft, setTimeLeft] = useState(duration);
    const [isActive, setIsActive] = useState(false);

    const audioContextRef = useRef<AudioContext | null>(null);
    const gainRef = useRef<GainNode | null>(null);
    const sourcesRef = useRef<AudioNode[]>([]);
    const timerRef = useRef<number | null>(null);

    const stopSession = useCallback(() => {
        if (timerRef.current) clearInterval(timerRef.current);
        if (audioContextRef.current && gainRef.current) {
            gainRef.current.gain.exponentialRampToValueAtTime(0.0001, audioContextRef.current.currentTime + 3);
            setTimeout(() => {
                audioContextRef.current?.close();
                audioContextRef.current = null;
                sourcesRef.current = [];
            }, 3500);
        }
        setIsActive(false);
    }, []);

    const startSession = () => {
        const ctx = new (window.AudioContext || (window as any).webkitAudioContext)();
        const mainGain = ctx.createGain();
        mainGain.gain.setValueAtTime(0, ctx.currentTime);
        mainGain.gain.exponentialRampToValueAtTime(0.2, ctx.currentTime + 5); // Fade in over 5s
        mainGain.connect(ctx.destination);
        
        // Base Drone (Schumann Resonance Pulse)
        const drone = ctx.createOscillator();
        drone.frequency.value = 136.1; // Om frequency
        const droneLfo = ctx.createOscillator();
        droneLfo.frequency.value = 7.83; // Schumann resonance
        const dronePulseGain = ctx.createGain();
        droneLfo.connect(dronePulseGain.gain);
        drone.connect(dronePulseGain).connect(mainGain);
        
        // Pink Noise
        const bufferSize = ctx.sampleRate * 2;
        const noiseBuffer = ctx.createBuffer(1, bufferSize, ctx.sampleRate);
        const output = noiseBuffer.getChannelData(0);
        let b0=0, b1=0, b2=0, b3=0, b4=0, b5=0, b6=0;
        for (let i = 0; i < bufferSize; i++) {
            const white = Math.random() * 2 - 1;
            b0 = 0.99886 * b0 + white * 0.0555179;
            b1 = 0.99332 * b1 + white * 0.0750759;
            b2 = 0.96900 * b2 + white * 0.1538520;
            b3 = 0.86650 * b3 + white * 0.3104856;
            b4 = 0.55000 * b4 + white * 0.5329522;
            b5 = -0.7616 * b5 - white * 0.0168980;
            output[i] = (b0 + b1 + b2 + b3 + b4 + b5 + b6 + white * 0.5362) * 0.11;
            b6 = white * 0.115926;
        }
        const noiseSource = ctx.createBufferSource();
        noiseSource.buffer = noiseBuffer;
        noiseSource.loop = true;
        const noiseGain = ctx.createGain();
        noiseGain.gain.value = 0.3;
        noiseSource.connect(noiseGain).connect(mainGain);

        drone.start();
        droneLfo.start();
        noiseSource.start();

        sourcesRef.current = [drone, droneLfo, noiseSource];
        audioContextRef.current = ctx;
        gainRef.current = mainGain;
        
        setIsActive(true);
        setTimeLeft(duration);

        timerRef.current = window.setInterval(() => {
            setTimeLeft(prev => {
                if (prev <= 1) {
                    stopSession();
                    return 0;
                }
                return prev - 1;
            });
        }, 1000);
    };
    
    useEffect(() => {
        return () => { // Cleanup on unmount
            stopSession();
        };
    }, [stopSession]);
    
    const formatTime = (seconds: number) => {
        const mins = Math.floor(seconds / 60);
        const secs = seconds % 60;
        return `${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
    };

    return (
        <div className="animate-fade-in">
            <h2 className="text-2xl font-bold text-brand-primary mb-1 tracking-widest">[MODULE] QUANTUM HEALING</h2>
            <p className="mb-4 text-brand-text-dark border-b-2 border-brand-primary/20 pb-2">Interface with the quantum field to harmonize mind, body, and spirit.</p>
            
            <div className="flex flex-col items-center justify-center">
                <div className={`relative w-64 h-64 flex items-center justify-center transition-all duration-1000 ${isActive ? 'scale-110' : 'scale-100'}`}>
                    {Array.from({ length: 5 }).map((_, i) => (
                       <div key={i} 
                            className="absolute rounded-full border border-brand-primary/30"
                            style={{
                                width: `${(i+1)*20}%`,
                                height: `${(i+1)*20}%`,
                                animation: isActive ? `pulse-glow ${4 + i*0.5}s infinite ease-in-out` : 'none',
                                animationDelay: `${i*0.3}s`
                            }}></div>
                    ))}
                    <div className="absolute w-full h-full rounded-full animate-spin-slow border-t-2 border-brand-accent"></div>
                    <div className="absolute text-center">
                        <p className="text-4xl font-bold text-brand-primary tracking-wider">{formatTime(timeLeft)}</p>
                        <p className="text-brand-text-dark">{isActive ? 'SESSION IN PROGRESS' : 'SYSTEM STANDBY'}</p>
                    </div>
                </div>

                <div className="w-full max-w-md mt-6 space-y-4">
                    <div className="bg-brand-bg/50 p-3 border border-brand-primary/20">
                        <h3 className="font-semibold text-lg text-brand-primary tracking-wider mb-3">[Log] Healing Focus</h3>
                        <textarea className="w-full h-20 p-2 bg-brand-surface border-2 border-brand-primary/30 rounded-none focus:border-brand-primary focus:ring-0 placeholder:text-brand-text-dark/50" placeholder="Enter your healing intention or focus area..."></textarea>
                    </div>

                    <div className="bg-brand-bg/50 p-3 border border-brand-primary/20">
                        <label className="block text-sm font-medium text-brand-text-dark tracking-wider mb-2">SESSION DURATION: {duration / 60} minutes</label>
                        <select value={duration} onChange={e => { setDuration(Number(e.target.value)); setTimeLeft(Number(e.target.value))}} disabled={isActive} className="w-full p-2 bg-brand-surface border-2 border-brand-primary/30 rounded-none disabled:opacity-50">
                            <option value={300}>5 Minutes</option>
                            <option value={600}>10 Minutes</option>
                            <option value={900}>15 Minutes</option>
                            <option value={1200}>20 Minutes</option>
                        </select>
                    </div>

                     <button onClick={isActive ? stopSession : startSession} className={`w-full font-bold py-3 px-8 transition-all duration-300 tracking-widest text-lg border-2 ${isActive ? 'bg-red-500 border-red-500 text-white hover:bg-red-600' : 'bg-brand-accent border-brand-accent text-brand-bg hover:shadow-glow hover:shadow-brand-accent/50'}`}>
                        {isActive ? 'END SESSION' : 'BEGIN SESSION'}
                     </button>
                </div>
            </div>
        </div>
    );
};

export default QuantumHealing;
