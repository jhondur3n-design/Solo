import React, { useState, useRef, useEffect, useCallback } from 'react';
import { Radio, ToggleSwitch } from '../components/Icons';
import Dial from '../components/Dial';

const RadionicsModule: React.FC = () => {
    const [targetImage, setTargetImage] = useState<string | null>(null);
    const [powerLevel, setPowerLevel] = useState(50);
    const [rate, setRate] = useState(50);
    const [emitterFrequency, setEmitterFrequency] = useState(432);
    const [isEmitterActive, setIsEmitterActive] = useState(false);
    const [status, setStatus] = useState<'idle' | 'analyzing' | 'broadcasting'>('idle');
    
    const audioContextRef = useRef<AudioContext | null>(null);
    const gainRef = useRef<GainNode | null>(null);
    const sourcesRef = useRef<AudioNode[]>([]);

    const stopBroadcasting = useCallback(() => {
        if (audioContextRef.current && gainRef.current) {
            gainRef.current.gain.exponentialRampToValueAtTime(0.0001, audioContextRef.current.currentTime + 1.5);
            
            const stopTime = audioContextRef.current.currentTime + 1.5;
            sourcesRef.current.forEach(source => {
                if (source instanceof OscillatorNode || source instanceof AudioBufferSourceNode) {
                    try {
                      source.stop(stopTime);
                    } catch(e) {
                      // an AudioBufferSourceNode can only be stopped once
                    }
                }
            });

            setTimeout(() => {
                audioContextRef.current?.close();
                audioContextRef.current = null;
                sourcesRef.current = [];
            }, 2000);
        }
        setStatus('idle');
    }, []);

    const startBroadcasting = () => {
        const audioCtx = new (window.AudioContext || (window as any).webkitAudioContext)();
        audioContextRef.current = audioCtx;
        const activeSources: AudioNode[] = [];

        // Main Gain
        const mainGain = audioCtx.createGain();
        mainGain.gain.setValueAtTime(0, audioCtx.currentTime);
        mainGain.gain.exponentialRampToValueAtTime(0.15, audioCtx.currentTime + 2);
        gainRef.current = mainGain;
        mainGain.connect(audioCtx.destination);

        // Radionic Hum (Base Oscillator)
        const baseOsc = audioCtx.createOscillator();
        (baseOsc as any).id = 'base';
        baseOsc.type = 'sine';
        baseOsc.frequency.setValueAtTime(40 + (powerLevel / 5), audioCtx.currentTime);
        
        // LFO for pulsing effect based on Rate
        const lfo = audioCtx.createOscillator();
        (lfo as any).id = 'lfo';
        lfo.frequency.value = rate / 10;
        const lfoGain = audioCtx.createGain();
        lfoGain.gain.value = 0.05; // Modulation depth
        lfo.connect(lfoGain).connect(mainGain.gain);
        
        // Pink Noise Generator for field texture
        const bufferSize = audioCtx.sampleRate * 2;
        const noiseBuffer = audioCtx.createBuffer(1, bufferSize, audioCtx.sampleRate);
        const output = noiseBuffer.getChannelData(0);
        let b0=0, b1=0, b2=0, b3=0, b4=0, b5=0, b6=0;
        for (let i = 0; i < bufferSize; i++) {
            const white = Math.random() * 2 - 1;
            b0 = 0.99886 * b0 + white * 0.0555179; b1 = 0.99332 * b1 + white * 0.0750759; b2 = 0.96900 * b2 + white * 0.1538520; b3 = 0.86650 * b3 + white * 0.3104856; b4 = 0.55000 * b4 + white * 0.5329522; b5 = -0.7616 * b5 - white * 0.0168980;
            output[i] = (b0 + b1 + b2 + b3 + b4 + b5 + b6 + white * 0.5362) * 0.11;
            b6 = white * 0.115926;
        }
        const noiseSource = audioCtx.createBufferSource();
        noiseSource.buffer = noiseBuffer;
        noiseSource.loop = true;
        const noiseGain = audioCtx.createGain();
        noiseGain.gain.value = 0.1;
        noiseSource.connect(noiseGain).connect(mainGain);
        
        baseOsc.connect(mainGain);
        activeSources.push(baseOsc, lfo, noiseSource);

        // Integrated Frequency Emitter
        if (isEmitterActive) {
            const emitterOsc = audioCtx.createOscillator();
            (emitterOsc as any).id = 'emitter';
            emitterOsc.type = 'triangle';
            emitterOsc.frequency.setValueAtTime(emitterFrequency, audioCtx.currentTime);
            const emitterGain = audioCtx.createGain();
            emitterGain.gain.value = 0.5; // Emitter is more prominent
            emitterOsc.connect(emitterGain).connect(mainGain);
            emitterOsc.start();
            activeSources.push(emitterOsc);
        }
        
        baseOsc.start();
        lfo.start();
        noiseSource.start();
        sourcesRef.current = activeSources;
        setStatus('broadcasting');
    };

    const handleBroadcastToggle = () => {
        if (status === 'idle') {
            setStatus('analyzing');
            setTimeout(startBroadcasting, 2500); // Simulate analysis
        } else if (status === 'broadcasting') {
            stopBroadcasting();
        }
    };
    
    useEffect(() => { // Real-time control during broadcast
        if(status === 'broadcasting' && audioContextRef.current){
            const baseOsc = sourcesRef.current.find(n => (n as any).id === 'base') as OscillatorNode;
            const lfo = sourcesRef.current.find(n => (n as any).id === 'lfo') as OscillatorNode;
            const emitterOsc = sourcesRef.current.find(n => (n as any).id === 'emitter') as OscillatorNode;

            baseOsc?.frequency.exponentialRampToValueAtTime(40 + (powerLevel / 5), audioContextRef.current.currentTime + 0.1);
            lfo?.frequency.exponentialRampToValueAtTime(rate / 10, audioContextRef.current.currentTime + 0.1);
            if (emitterOsc) {
                emitterOsc.frequency.exponentialRampToValueAtTime(emitterFrequency, audioContextRef.current.currentTime + 0.1);
            }
        }
    }, [powerLevel, rate, emitterFrequency, status]);

    useEffect(() => { // Cleanup on unmount
        return stopBroadcasting;
    }, [stopBroadcasting]);

    const handleImageUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
        const file = event.target.files?.[0];
        if (file) {
            const reader = new FileReader();
            reader.onload = (e) => setTargetImage(e.target?.result as string);
            reader.readAsDataURL(file);
        }
    };

    const buttonConfig = {
        idle: { text: 'ANALYZE & BROADCAST', class: 'bg-brand-accent border-brand-accent text-brand-bg hover:shadow-glow hover:shadow-brand-accent/50' },
        analyzing: { text: 'ANALYZING...', class: 'bg-brand-secondary border-brand-secondary text-white animate-pulse' },
        broadcasting: { text: 'CEASE BROADCAST', class: 'bg-red-500 border-red-500 text-white hover:bg-red-600' },
    };
    
    const StatusIndicator: React.FC<{label: string, active: boolean, color: string}> = ({label, active, color}) => (
      <div className="flex items-center space-x-2">
        <div className={`w-3 h-3 rounded-full transition-all duration-300 ${active ? color : 'bg-brand-bg'}`} style={active ? {boxShadow: `0 0 8px ${color.replace('bg-', '')}`} : {}}></div>
        <span className={`tracking-widest font-semibold ${active ? 'text-brand-text' : 'text-brand-text-dark'}`}>{label}</span>
      </div>
    )

    return (
        <div className="animate-fade-in">
            <h2 className="text-2xl font-bold text-brand-primary mb-1 tracking-widest">[MODULE] RADIONICS</h2>
            <p className="mb-4 text-brand-text-dark border-b-2 border-brand-primary/20 pb-2">Focus and broadcast intention through energetic fields.</p>
            
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                {/* Left Panel: Inputs */}
                <div className="bg-brand-bg/50 p-3 border border-brand-primary/20 space-y-4">
                    <div>
                        <h3 className="font-semibold text-lg text-brand-primary tracking-wider mb-2">[System] Witness Plate</h3>
                        <label htmlFor="sigil-upload" className="block w-full h-32 border-2 border-dashed border-brand-primary/30 flex items-center justify-center cursor-pointer hover:border-brand-primary hover:bg-brand-surface/50">
                            {targetImage ? (
                                <img src={targetImage} alt="Target Sigil" className="w-full h-full object-contain" />
                            ) : (
                                <span className="text-brand-text-dark">Upload Target Sigil</span>
                            )}
                        </label>
                        <input id="sigil-upload" type="file" accept="image/*" onChange={handleImageUpload} className="hidden"/>
                    </div>
                     <div>
                        <h3 className="font-semibold text-lg text-brand-primary tracking-wider mb-2">[Log] Intention Field</h3>
                        <textarea className="w-full h-24 p-2 bg-brand-surface border-2 border-brand-primary/30 rounded-none focus:border-brand-primary focus:ring-0 placeholder:text-brand-text-dark/50" placeholder="Input your intention, wish, or goal..."></textarea>
                    </div>
                </div>

                {/* Right Panel: Controls & Dish */}
                <div className="bg-brand-bg/50 p-3 border border-brand-primary/20 flex flex-col items-center justify-around space-y-4">
                    <div className="relative w-56 h-56 flex items-center justify-center">
                        {status !== 'idle' && Array.from({ length: 4 }).map((_, i) => (
                           <div key={i} className="absolute rounded-full border-2 border-brand-primary/50"
                                style={{
                                    width: `${(i+1)*25}%`, height: `${(i+1)*25}%`,
                                    animation: `pulse-glow ${status === 'analyzing' ? 0.5 : 2 + i*0.5}s infinite ease-in-out`,
                                    animationDelay: `${i*0.1}s`
                                }}></div>
                        ))}
                        <div className="relative w-40 h-40 bg-brand-surface rounded-full flex items-center justify-center border-2 border-brand-primary/30 overflow-hidden">
                            <Radio className={`w-20 h-20 transition-colors duration-500 ${status !== 'idle' ? 'text-brand-primary' : 'text-brand-primary/30'}`} />
                            {status === 'broadcasting' && <div className="absolute w-full h-full border-t-2 border-brand-accent animate-spin-slow"></div>}
                        </div>
                    </div>
                    <div className="w-full flex justify-around">
                        <Dial label="Power" value={powerLevel} onChange={setPowerLevel} min={0} max={100} />
                        <Dial label="Signature" value={rate} onChange={setRate} min={0} max={100} />
                    </div>
                </div>
                
                {/* Bottom Panel: Emitter & Action */}
                <div className="lg:col-span-2 bg-brand-bg/50 p-3 border border-brand-primary/20 flex flex-col md:flex-row gap-4">
                    <div className="flex-1 bg-brand-surface p-3 border border-brand-primary/20 flex flex-col items-center justify-center">
                        <h3 className="font-semibold text-lg text-brand-primary tracking-wider mb-2">FREQUENCY EMITTER</h3>
                        <div className='flex items-center gap-4'>
                            <button onClick={() => setIsEmitterActive(!isEmitterActive)} disabled={status !== 'idle'}>
                                <ToggleSwitch on={isEmitterActive} />
                            </button>
                            <Dial label={`${emitterFrequency} Hz`} value={emitterFrequency} onChange={setEmitterFrequency} min={40} max={1000} disabled={!isEmitterActive || status !== 'idle'}/>
                        </div>
                    </div>
                    <div className="flex-1 bg-brand-surface p-3 border-2 border-brand-accent/80 flex flex-col items-center justify-center gap-4">
                        <div className="flex flex-col items-start gap-2">
                          <StatusIndicator label="STANDBY" active={status === 'idle'} color="bg-blue-500" />
                          <StatusIndicator label="ANALYZING" active={status === 'analyzing'} color="bg-yellow-400" />
                          <StatusIndicator label="BROADCASTING" active={status === 'broadcasting'} color="bg-green-500" />
                        </div>
                        <button onClick={handleBroadcastToggle} disabled={status === 'analyzing'} className={`w-full font-bold py-3 px-8 transition-all duration-300 tracking-widest text-lg border-2 disabled:cursor-not-allowed ${buttonConfig[status].class}`}>
                            {buttonConfig[status].text}
                        </button>
                    </div>
                </div>

            </div>
        </div>
    );
};

export default RadionicsModule;