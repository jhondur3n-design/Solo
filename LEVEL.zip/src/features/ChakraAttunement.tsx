import React, { useState, useRef, useEffect } from 'react';
import { Play, Pause } from '../components/Icons';

const chakraData = [
  { name: 'Crown', sanskrit: 'Sahasrara', frequency: 963, color: '#a855f7', description: 'Connection to the divine, spirituality, and pure consciousness.' },
  { name: 'Third Eye', sanskrit: 'Ajna', frequency: 852, color: '#6366f1', description: 'Intuition, foresight, and imagination. Seeing beyond the physical.' },
  { name: 'Throat', sanskrit: 'Vishuddha', frequency: 741, color: '#3b82f6', description: 'Communication, self-expression, and truth. Speaking your reality.' },
  { name: 'Heart', sanskrit: 'Anahata', frequency: 639, color: '#22c55e', description: 'Love, compassion, relationships, and emotional balance.' },
  { name: 'Solar Plexus', sanskrit: 'Manipura', frequency: 528, color: '#eab308', description: 'Personal power, self-esteem, and the will to create change.' },
  { name: 'Sacral', sanskrit: 'Svadhisthana', frequency: 417, color: '#f97316', description: 'Creativity, emotions, and pleasure. The flow of life.' },
  { name: 'Root', sanskrit: 'Muladhara', frequency: 396, color: '#ef4444', description: 'Grounding, security, and the fundamental sense of stability.' },
];

const ChakraAttunement: React.FC = () => {
    const [selectedChakraIndex, setSelectedChakraIndex] = useState<number | null>(null);
    const [isPlaying, setIsPlaying] = useState(false);
    const [volume, setVolume] = useState(25);

    const audioContextRef = useRef<AudioContext | null>(null);
    const oscillatorRef = useRef<OscillatorNode | null>(null);
    const gainRef = useRef<GainNode | null>(null);

    const stopSound = () => {
        if (audioContextRef.current) {
            audioContextRef.current.close().then(() => {
                audioContextRef.current = null;
                oscillatorRef.current = null;
                gainRef.current = null;
                setIsPlaying(false);
            });
        }
    };

    const playSound = (frequency: number) => {
        if (isPlaying) stopSound();

        const ctx = new (window.AudioContext || (window as any).webkitAudioContext)();
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();

        osc.type = 'sine';
        osc.frequency.value = frequency;
        gain.gain.value = volume / 100;

        osc.connect(gain).connect(ctx.destination);
        osc.start();

        audioContextRef.current = ctx;
        oscillatorRef.current = osc;
        gainRef.current = gain;
        setIsPlaying(true);
    };

    const handlePlayToggle = () => {
        if (selectedChakraIndex === null) return;
        
        if (isPlaying) {
            stopSound();
        } else {
            playSound(chakraData[selectedChakraIndex].frequency);
        }
    };
    
    const handleChakraSelect = (index: number) => {
        if (isPlaying) {
            stopSound();
        }
        setSelectedChakraIndex(index);
    };

    useEffect(() => {
        if (isPlaying && gainRef.current && audioContextRef.current) {
            gainRef.current.gain.setValueAtTime(volume / 100, audioContextRef.current.currentTime);
        }
    }, [volume, isPlaying]);

    // Cleanup on unmount
    useEffect(() => {
        return () => {
            if (isPlaying) stopSound();
        };
    }, [isPlaying]);

    const activeChakra = selectedChakraIndex !== null ? chakraData[selectedChakraIndex] : null;

    return (
        <div className="animate-fade-in">
            <h2 className="text-2xl font-bold text-brand-primary mb-1 tracking-widest">[MODULE] CHAKRA ATTUNEMENT</h2>
            <p className="mb-4 text-brand-text-dark border-b-2 border-brand-primary/20 pb-2">Align and balance your energetic centers using specific frequencies.</p>

            <div className="flex flex-col lg:flex-row gap-4">
                <div className="lg:w-1/3 bg-brand-bg/50 p-3 border border-brand-primary/20 space-y-2">
                    {chakraData.map((chakra, index) => (
                        <button key={chakra.name} onClick={() => handleChakraSelect(index)} 
                            className={`w-full text-left p-2 transition-all duration-300 flex items-center border-l-4 ${selectedChakraIndex === index ? 'bg-brand-surface' : 'bg-transparent hover:bg-brand-surface/50'}`}
                            style={{ borderColor: selectedChakraIndex === index ? chakra.color : 'transparent' }}
                        >
                            <div className="w-4 h-4 rounded-full mr-3" style={{ backgroundColor: chakra.color }}></div>
                            <span className="font-semibold tracking-wider">{chakra.name}</span>
                        </button>
                    ))}
                </div>

                <div className="lg:w-2/3 bg-brand-bg/50 p-3 border border-brand-primary/20 flex flex-col items-center justify-center text-center min-h-[300px]">
                    {activeChakra ? (
                        <>
                            <div className="relative mb-4">
                               <div className="w-24 h-24 rounded-full transition-all duration-500" style={{ backgroundColor: activeChakra.color, boxShadow: isPlaying ? `0 0 25px ${activeChakra.color}`: 'none' }}></div>
                               {isPlaying && <div className="absolute top-0 left-0 w-24 h-24 rounded-full border-2 animate-ping" style={{ borderColor: activeChakra.color }}></div>}
                            </div>
                            <h3 className="text-2xl font-bold tracking-wider" style={{ color: activeChakra.color }}>{activeChakra.name} ({activeChakra.sanskrit})</h3>
                            <p className="text-lg text-brand-primary">{activeChakra.frequency} Hz</p>
                            <p className="mt-2 text-brand-text-dark max-w-sm">{activeChakra.description}</p>
                           
                            <div className="w-full max-w-xs mt-6 space-y-4">
                                <div>
                                    <label className="block text-sm text-center font-medium text-brand-text-dark tracking-wider mb-2">VOLUME: {volume}%</label>
                                    <input type="range" min="0" max="100" value={volume} onChange={e => setVolume(Number(e.target.value))} className="w-full h-2 bg-brand-primary/30 rounded-lg appearance-none cursor-pointer" style={{accentColor: activeChakra.color}}/>
                                </div>
                                <button onClick={handlePlayToggle} className={`w-full flex items-center justify-center p-3 border-2 font-bold tracking-widest text-lg transition-colors duration-300`}
                                    style={{
                                        borderColor: activeChakra.color,
                                        color: isPlaying ? '#020418' : activeChakra.color,
                                        backgroundColor: isPlaying ? activeChakra.color : 'transparent',
                                    }}
                                >
                                    {isPlaying ? <Pause className="w-6 h-6 mr-3" /> : <Play className="w-6 h-6 mr-3" />}
                                    {isPlaying ? 'STOP' : 'PLAY'}
                                </button>
                            </div>
                        </>
                    ) : (
                         <p className="text-brand-text-dark">Select a chakra to begin attunement.</p>
                    )}
                </div>
            </div>
        </div>
    );
};

export default ChakraAttunement;
