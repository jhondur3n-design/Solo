import React, { useState, useCallback, useEffect } from 'react';
import { Feature, ActiveTab } from './types';
import TabButton from './components/TabButton';
import SubliminalMaker from './features/SubliminalMaker';
import SubliminalAmplifier from './features/SubliminalAmplifier';
import RadionicsModule from './features/RadionicsModule';
import FrequencyGenerator from './features/FrequencyGenerator';
import ChakraAttunement from './features/ChakraAttunement';
import QuantumHealing from './features/QuantumHealing';
import Instructions from './features/Instructions';
import { BrainCircuit, Dna, Disc, Radio, Download, Lotus, Atom, BookOpen } from './components/Icons';

const App: React.FC = () => {
  const [activeTab, setActiveTab] = useState<ActiveTab>('instructions');
  const [installPrompt, setInstallPrompt] = useState<any>(null);

  useEffect(() => {
    const handler = (e: Event) => {
        e.preventDefault();
        setInstallPrompt(e);
    };
    window.addEventListener('beforeinstallprompt', handler);
    return () => window.removeEventListener('beforeinstallprompt', handler);
  }, []);

  const handleInstallClick = () => {
    if (!installPrompt) return;
    installPrompt.prompt();
    installPrompt.userChoice.then((choiceResult: { outcome: string }) => {
        if (choiceResult.outcome === 'accepted') {
            console.log('User accepted the install prompt');
        } else {
            console.log('User dismissed the install prompt');
        }
        setInstallPrompt(null);
    });
  };

  const renderContent = useCallback(() => {
    switch (activeTab) {
      case 'instructions':
        return <Instructions />;
      case 'subliminalMaker':
        return <SubliminalMaker />;
      case 'subliminalAmplifier':
        return <SubliminalAmplifier />;
      case 'radionicsModule':
        return <RadionicsModule />;
      case 'frequencyGenerator':
        return <FrequencyGenerator />;
      case 'chakraAttunement':
        return <ChakraAttunement />;
      case 'quantumHealing':
        return <QuantumHealing />;
      default:
        return <Instructions />;
    }
  }, [activeTab]);

  const features: Feature[] = [
    { id: 'instructions', label: 'Manual', icon: <BookOpen /> },
    { id: 'subliminalMaker', label: 'Subliminal Creation', icon: <Dna /> },
    { id: 'subliminalAmplifier', label: 'Amplifier', icon: <BrainCircuit /> },
    { id: 'radionicsModule', label: 'Radionics', icon: <Radio /> },
    { id: 'frequencyGenerator', label: 'Frequencies', icon: <Disc /> },
    { id: 'chakraAttunement', label: 'Chakra Attunement', icon: <Lotus /> },
    { id: 'quantumHealing', label: 'Quantum Healing', icon: <Atom /> },
  ];

  return (
    // This outer container enforces a strict full-height layout, crucial for a native-like feel.
    <div className="h-screen bg-transparent flex flex-col font-sans">
      {/* This inner container manages padding, max-width, and contains the app's main flex structure. */}
      <div className="w-full max-w-screen-2xl mx-auto flex flex-col flex-grow p-2 sm:p-3 min-h-0">
        
        <header className="text-center p-3 bg-brand-surface/80 backdrop-blur-sm border-t border-b border-brand-primary/50 relative flex-shrink-0">
          <div className="absolute top-0 left-0 w-6 h-6 border-t-2 border-l-2 border-brand-primary"></div>
          <div className="absolute top-0 right-0 w-6 h-6 border-t-2 border-r-2 border-brand-primary"></div>
          <div className="absolute bottom-0 left-0 w-6 h-6 border-b-2 border-l-2 border-brand-primary"></div>
          <div className="absolute bottom-0 right-0 w-6 h-6 border-b-2 border-r-2 border-brand-primary"></div>
          <h1 className="text-2xl sm:text-3xl font-bold text-brand-primary tracking-widest uppercase">
            System Interface
          </h1>
          
          <div className="mt-2 inline-flex items-center justify-center bg-brand-bg/50 px-6 py-1 border border-brand-accent/60 shadow-lg shadow-brand-accent/20">
              <span 
                className="text-brand-accent font-bold tracking-[0.2em] text-lg"
                style={{ textShadow: '0 0 6px rgba(253, 216, 53, 0.7)' }}
              >
                LVL. MAX
              </span>
          </div>
        </header>

        <main className="flex-grow flex flex-col gap-3 mt-3 min-h-0">
          <nav className="bg-brand-surface/80 backdrop-blur-sm p-1 border-y border-brand-primary/30 w-full flex-shrink-0">
            <div className="flex flex-row flex-wrap items-center justify-center gap-1">
                {features.map(feature => (
                  <TabButton
                    key={feature.id}
                    label={feature.label}
                    icon={feature.icon}
                    isActive={activeTab === feature.id}
                    onClick={() => setActiveTab(feature.id)}
                  />
                ))}
                {installPrompt && (
                    <TabButton
                        label="INSTALL APP"
                        icon={<Download />}
                        isActive={false}
                        onClick={handleInstallClick}
                        accent
                      />
                )}
              </div>
          </nav>
          
          <div className="flex-grow bg-brand-surface/80 backdrop-blur-sm p-3 sm:p-4 border border-brand-primary/30 overflow-y-auto relative min-h-0">
            <div className="absolute -top-px -left-px w-4 h-4 border-t-2 border-l-2 border-brand-primary"></div>
            <div className="absolute -top-px -right-px w-4 h-4 border-t-2 border-r-2 border-brand-primary"></div>
            <div className="absolute -bottom-px -left-px w-4 h-4 border-b-2 border-l-2 border-brand-primary"></div>
            <div className="absolute -bottom-px -right-px w-4 h-4 border-b-2 border-r-2 border-brand-primary"></div>
            {renderContent()}
          </div>
        </main>

        <footer className="text-center p-2 mt-3 text-xs text-brand-text-dark flex-shrink-0">
          <p>SYSTEM KERNEL V2.0 // CREATOR: <span className="font-semibold text-brand-primary/80">jhondurd3n x AI</span>.</p>
          <p className="mt-1">WARNING: FOR PERSONAL USE ONLY. UNAUTHORIZED ACCESS IS PROHIBITED.</p>
        </footer>
      </div>
    </div>
  );
};

export default App;